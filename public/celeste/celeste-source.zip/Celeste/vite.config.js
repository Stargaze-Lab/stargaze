import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';

const projectRoot = fileURLToPath(new URL('.', import.meta.url));
const embeddedInStargaze = process.env.CELESTE_STARGAZE_BUILD === '1';

export default defineConfig({
  root: projectRoot,
  base: './',
  assetsInclude: ['**/*.wasm', '**/*.data'],
  optimizeDeps: {
    exclude: ['swisseph-wasm'],
  },
  build: {
    target: 'es2020',
    outDir: embeddedInStargaze ? '../../public/celeste' : 'dist',
    emptyOutDir: true,
  },
});
