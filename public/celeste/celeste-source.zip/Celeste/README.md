# Celeste · V1.1.0

Estudo interativo Stargaze que aproxima duas formas de ver um mesmo instante: o céu observado de uma localização e sua tradução astrológica em um mapa natal.

Interface responsiva para desktop, iPad e celulares, com navegação por toque, arraste e pinça.

## Executar

```bash
npm install
npm run dev
```

## Validar e publicar

```bash
npm test
npm run build
```

O build produz `dist/`, que pode ser publicado em hospedagem estática. Ele também gera `public/celeste-source.zip` e o inclui na publicação, acessível pela página `source.html`.

## O que existe nesta versão

- Quatro modos: abóbada esférica, disco eclíptico, imersão 360° e mapa natal.
- Céu completo acima e abaixo do horizonte, grade em graus, zoom e pan.
- Estrelas de destaque, constelações e planetas identificáveis por clique; a constelação selecionada ganha um traço sólido luminoso e ilumina somente as estrelas correspondentes aos vértices do desenho.
- Estrelas principais usam a forma radiante de oito pontas; destaques menores usam quatro pontas.
- Mapa natal inicial com planetas, Nodo Norte verdadeiro, Quíron, retrógrados, signos em SVG, casas Placidus, ASC/MC/DSC/IC e aspectos principais.
- Projeção natal espelhada no padrão visual de mapas astrológicos: casas avançando no sentido anti-horário a partir do setor inferior ao ASC.
- ASC e MC intercalados na lista de posições e disponíveis para destaque e leitura rápida.
- Cartões de leitura rápida no lado esquerdo combinando astro, signo e casa, sem produzir uma interpretação personalizada automática.
- Gráficos percentuais de elementos e modalidades, calculados com peso igual sobre os dez astros principais.
- Segmentos e legendas dos gráficos respondem a hover, foco e toque, exibindo categoria e percentual.
- Aspectos clicáveis, destacados no mapa e acompanhados de uma descrição sintética.
- Aspectos agrupados por tipo e painéis laterais mais estreitos para preservar a área do mapa.
- Horário desconhecido explicitamente tratado como estimado; nesse caso, casas e ascendente não são apresentados como precisos.
- Toggle PT/EN, busca de lugar e botão “o céu agora” usando a localização e o horário atuais.
- Controles A−/A+ ajustam globalmente a tipografia da interface e preservam a preferência no navegador.
- Nomes oficiais latinos das constelações permanecem iguais em PT e EN.

## Modelos de dados

- **Planetas no céu observado:** Swiss Ephemeris calcula posições topocêntricas e sua projeção no horizonte local.
- **Mapa natal:** Swiss Ephemeris calcula longitudes eclípticas geocêntricas, zodíaco tropical e casas Placidus.
- **Estrelas e constelações:** Astronomy Engine transforma o catálogo estelar para o horizonte do lugar e instante escolhidos.

Os resultados não devem ocupar a mesma geometria: são projeções e referenciais distintos do mesmo instante. Para comparar o mapa natal com outra calculadora, use exatamente o mesmo horário, fuso, zodíaco e sistema de casas.

No disco, os glifos representam os doze setores iguais do zodíaco tropical. As linhas e nomes representam constelações astronômicas, que não coincidem com esses setores devido à precessão dos equinócios.

## Código aberto e créditos

Celeste é distribuído sob **GNU Affero General Public License v3.0 ou posterior**. Veja `LICENSE` e `NOTICE.md`.

O mapa natal usa Swiss Ephemeris sob sua opção AGPL e `swisseph-wasm` para execução local no navegador. Astronomy Engine, Three.js, d3-celestial e Open-Meteo são creditados em `NOTICE.md`.

## Limites atuais

- O pacote WebAssembly inclui efemérides para o intervalo suportado pelo wrapper selecionado (aproximadamente 1800–2400).
- Não há contas, interpretações astrológicas textuais, exportação 3D ou personalização avançada nesta etapa.
- Celeste não é afiliado, patrocinado ou endossado pela Astrodienst AG.

## Próxima integração

A proposta para o botão de interpretação por LLM está documentada em `docs/INTERPRETACAO_GENERATIVA.md`. A chave do provedor deve permanecer em um endpoint protegido no servidor, nunca no código público do navegador.
