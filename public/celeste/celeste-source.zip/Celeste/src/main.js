import './styles.css';
import { SkyDome } from './dome.js';
import { calculateSky, localDateToUtc } from './sky-data.js';
import { calculateSwissChart, initializeSwissEphemeris } from './swiss-data.js';
import { copy, formatDate } from './i18n.js';
import { ZODIAC_DATA, zodiacSvg } from './zodiac-icons.js';

const app = document.querySelector('#app');

const state = {
  language: 'pt',
  mode: 'form',
  date: '',
  time: '12:00',
  unknownTime: true,
  location: null,
  sky: null,
  layers: { planets: true, constellations: true, names: false, houses: true },
  density: 'high',
  view: 'dome',
  textSize: 0,
};

app.innerHTML = `
  <main class="experience" data-mode="form">
    <header class="topbar">
      <a class="brand" href="https://stargaze.glitchme.art/" aria-label="Stargaze">
        <span class="brand-mark" aria-hidden="true">✦</span>
        <span>stargaze</span>
      </a>
      <div class="top-tools">
        <div class="top-control-row">
          <div class="language-switch" role="group" aria-label="Language">
            <button type="button" data-language="pt" aria-pressed="true">PT</button>
            <span aria-hidden="true">/</span>
            <button type="button" data-language="en" aria-pressed="false">EN</button>
          </div>
          <span class="top-control-divider" aria-hidden="true"></span>
          <div class="text-size-control" role="group" data-copy-aria="textSizeControls" aria-label="Tamanho do texto">
            <button type="button" data-text-size="decrease" data-copy-aria="decreaseText" aria-label="Diminuir texto">A−</button>
            <button type="button" data-text-size="increase" data-copy-aria="increaseText" aria-label="Aumentar texto">A+</button>
          </div>
        </div>
        <button class="settings-button" type="button" data-action="open-settings" aria-expanded="false">
          <span aria-hidden="true">◌</span><span data-copy="settings"></span>
        </button>
      </div>
    </header>

    <section class="editorial-panel">
      <div class="editorial-inner">
        <h1><span data-copy="titleMain"></span> <em data-copy="titleItalic"></em></h1>
        <p class="home-subtitle" data-copy="atlasPersonal"></p>
        <p class="intro" data-copy="intro"></p>

        <form class="sky-form" novalidate>
          <div class="field location-field">
            <label for="location" data-copy="location"></label>
            <div class="location-input-wrap">
              <input id="location" name="location" type="search" autocomplete="off" data-placeholder="locationPlaceholder" aria-describedby="location-help location-status" />
              <span class="field-orbit" aria-hidden="true"></span>
            </div>
            <p class="field-help" id="location-help" data-copy="locationHelp"></p>
            <div class="location-results" role="listbox" hidden></div>
            <p class="field-status" id="location-status" aria-live="polite"></p>
          </div>

          <div class="date-time-grid">
            <div class="field">
              <label for="birth-date" data-copy="date"></label>
              <input id="birth-date" name="date" type="date" required />
            </div>
            <div class="field">
              <label for="birth-time" data-copy="time"></label>
              <input id="birth-time" name="time" type="time" aria-describedby="time-help" />
              <p class="field-help" id="time-help" data-copy="timeOptional"></p>
            </div>
          </div>

          <p class="form-error" role="alert"></p>
          <div class="form-actions">
            <button class="primary-button" type="submit">
              <span class="button-star" aria-hidden="true">✦</span>
              <span data-copy="submit"></span>
              <span class="button-line" aria-hidden="true"></span>
            </button>
            <button class="now-button" type="button"><span aria-hidden="true">◉</span><span data-copy="skyNow"></span></button>
          </div>
        </form>

        <div class="result-copy" aria-live="polite">
          <h2 class="result-place"></h2>
          <p class="result-date"></p>
          <p class="result-time"></p>
          <button class="text-button edit-button" type="button" data-copy="edit"></button>
        </div>
      </div>
    </section>

    <section class="sky-stage" aria-label="Mapa celeste interativo">
      <div class="stage-glow" aria-hidden="true"></div>
      <div class="sky-canvas"></div>
      <div class="webgl-error" hidden></div>
      <p class="drag-instruction"><span aria-hidden="true">↔</span> <span data-copy="instruction"></span></p>

      <nav class="view-toolbar" aria-label="Modos de visualização">
        <div class="view-control">
          <span class="control-label" data-copy="view"></span>
          <div class="mode-buttons" role="group">
            <button type="button" data-view="natal" data-copy="natalView"></button>
            <button type="button" data-view="dome" class="is-active" data-copy="domeView"></button>
            <button type="button" data-view="disc" data-copy="discView"></button>
            <button type="button" data-view="inside" data-copy="insideView"></button>
          </div>
        </div>
      </nav>

      <aside class="layer-panel" aria-label="Camadas do céu">
        <div class="layer-heading">
          <span><span class="tiny-star" aria-hidden="true">✦</span> <span data-copy="filters"></span></span>
          <button class="close-panel" type="button" data-action="close-settings" data-copy-aria="closeSettings" aria-label="Fechar ajustes">×</button>
        </div>
        <div class="toggle-row">
          <button type="button" class="filter-toggle is-on" data-layer="constellations" aria-pressed="true"><span data-copy="constellations"></span></button>
          <button type="button" class="filter-toggle is-on" data-layer="planets" aria-pressed="true"><span data-copy="planets"></span></button>
          <button type="button" class="filter-toggle" data-layer="names" aria-pressed="false"><span data-copy="names"></span></button>
          <button type="button" class="filter-toggle is-on" data-layer="houses" aria-pressed="true"><span data-copy="symbolicHouses"></span></button>
        </div>
        <div class="density-control">
          <span data-copy="density"></span>
          <div class="segmented" role="group" aria-label="Densidade de estrelas">
            <button type="button" data-density="low"><span data-copy="low"></span></button>
            <button type="button" data-density="medium"><span data-copy="medium"></span></button>
            <button type="button" data-density="high" class="is-active"><span data-copy="high"></span></button>
          </div>
        </div>
        <p class="symbolic-note" data-copy="symbolicNote"></p>
        <p class="source-note">
          <span data-copy="poweredBySwiss"></span> ·
          <a href="./source.html" target="_blank" rel="noreferrer" data-copy="sourceAndCredits"></a>
        </p>
      </aside>

      <aside class="selection-card" hidden aria-live="polite">
        <span class="selection-glyph" aria-hidden="true">✦</span>
        <div class="selection-copy">
          <p class="selection-kind"></p>
          <h3 class="selection-name"></h3>
          <p class="selection-meta"></p>
        </div>
        <button type="button" class="clear-selection" data-copy-aria="clearSelection" aria-label="Limpar destaque">×</button>
        <div class="selection-details"></div>
      </aside>

      <aside class="natal-panel" hidden>
        <div class="natal-panel-heading">
          <div><span data-copy="natalReading"></span><small class="natal-model"></small></div>
          <span aria-hidden="true">☉</span>
        </div>
        <p class="natal-caveat"></p>
        <div class="natal-list"></div>
        <section class="chart-balance">
          <div class="chart-balance-heading"><span data-copy="mapBalance"></span><small data-copy="balanceBasis"></small></div>
          <div class="balance-chart" data-balance="elements">
            <p data-copy="elements"></p><div class="stacked-bar"></div><p class="balance-readout" aria-live="polite"></p><div class="balance-legend"></div>
          </div>
          <div class="balance-chart" data-balance="modalities">
            <p data-copy="modalities"></p><div class="stacked-bar"></div><p class="balance-readout" aria-live="polite"></p><div class="balance-legend"></div>
          </div>
        </section>
        <details class="aspect-details">
          <summary><span data-copy="majorAspects"></span><span class="aspect-count"></span></summary>
          <div class="aspect-legend"></div>
          <div class="aspect-list"></div>
        </details>
      </aside>

      <div class="sky-tooltip" hidden></div>

      <div class="stage-caption">
        <span class="caption-rule" aria-hidden="true"></span>
        <span data-copy="astronomyNote"></span>
      </div>
    </section>

    <nav class="floating-panel-dock" aria-label="Painéis fechados"></nav>

    <div class="loading-screen" aria-live="assertive" aria-busy="true">
      <div class="loading-orbit" aria-hidden="true"><span>✦</span></div>
      <p data-copy="loading"></p>
    </div>
  </main>
`;

const experience = document.querySelector('.experience');
const form = document.querySelector('.sky-form');
const locationInput = document.querySelector('#location');
const locationResults = document.querySelector('.location-results');
const locationStatus = document.querySelector('#location-status');
const dateInput = document.querySelector('#birth-date');
const timeInput = document.querySelector('#birth-time');
const formError = document.querySelector('.form-error');
const submitButton = document.querySelector('.primary-button');
const nowButton = document.querySelector('.now-button');
const webglError = document.querySelector('.webgl-error');
const layerPanel = document.querySelector('.layer-panel');
const settingsButton = document.querySelector('.settings-button');
const selectionCard = document.querySelector('.selection-card');
const selectionGlyph = document.querySelector('.selection-glyph');
const selectionKind = document.querySelector('.selection-kind');
const selectionName = document.querySelector('.selection-name');
const selectionMeta = document.querySelector('.selection-meta');
const selectionDetails = document.querySelector('.selection-details');
const skyTooltip = document.querySelector('.sky-tooltip');
const natalPanel = document.querySelector('.natal-panel');
const natalModel = document.querySelector('.natal-model');
const natalCaveat = document.querySelector('.natal-caveat');
const natalList = document.querySelector('.natal-list');
const aspectCount = document.querySelector('.aspect-count');
const aspectLegend = document.querySelector('.aspect-legend');
const aspectList = document.querySelector('.aspect-list');
const compactLayoutQuery = window.matchMedia('(max-width: 1100px)');
const textSizeButtons = document.querySelectorAll('[data-text-size]');
const floatingPanelDock = document.querySelector('.floating-panel-dock');
dateInput.min = '1800-01-01';
dateInput.max = new Date().toISOString().slice(0, 10);

let searchTimer;
let searchRequest;
let generationRequestId = 0;
let floatingZIndex = 40;
const zodiac = {
  pt: [['♈', 'Áries'], ['♉', 'Touro'], ['♊', 'Gêmeos'], ['♋', 'Câncer'], ['♌', 'Leão'], ['♍', 'Virgem'], ['♎', 'Libra'], ['♏', 'Escorpião'], ['♐', 'Sagitário'], ['♑', 'Capricórnio'], ['♒', 'Aquário'], ['♓', 'Peixes']],
  en: [['♈', 'Aries'], ['♉', 'Taurus'], ['♊', 'Gemini'], ['♋', 'Cancer'], ['♌', 'Leo'], ['♍', 'Virgo'], ['♎', 'Libra'], ['♏', 'Scorpio'], ['♐', 'Sagittarius'], ['♑', 'Capricorn'], ['♒', 'Aquarius'], ['♓', 'Pisces']],
};

const floatingPanels = [];

function updateFloatingPanelCopy() {
  const text = copy[state.language];
  floatingPanelDock.setAttribute('aria-label', text.closedPanels);
  floatingPanels.forEach(({ panel, titleKey, title, minimize, close, restore }) => {
    const label = text[titleKey] || titleKey;
    title.textContent = label;
    minimize.setAttribute('aria-label', panel.classList.contains('is-minimized') ? text.restorePanel : text.minimizePanel);
    close.setAttribute('aria-label', text.closePanel);
    restore.textContent = label;
    restore.setAttribute('aria-label', `${text.restorePanel}: ${label}`);
  });
}

function restoreFloatingPanel(item) {
  item.panel.classList.remove('is-panel-closed', 'is-minimized');
  item.panel.removeAttribute('data-panel-closed');
  item.restore.hidden = true;
  item.minimize.setAttribute('aria-expanded', 'true');
  item.panel.style.zIndex = String(++floatingZIndex);
}

function closeFloatingPanel(item) {
  if (item.id === 'selection') {
    item.restore.hidden = true;
    dome.setSelection(null);
    return;
  }
  item.panel.classList.add('is-panel-closed');
  item.panel.dataset.panelClosed = 'true';
  item.restore.hidden = false;
  if (item.id === 'settings') {
    item.panel.classList.remove('is-open');
    settingsButton.setAttribute('aria-expanded', 'false');
  }
}

function toggleFloatingPanel(item) {
  const minimized = item.panel.classList.toggle('is-minimized');
  item.minimize.setAttribute('aria-expanded', String(!minimized));
  item.minimize.setAttribute('aria-label', copy[state.language][minimized ? 'restorePanel' : 'minimizePanel']);
}

function fitFloatingPanel(panel) {
  if (!compactLayoutQuery.matches || !panel.style.left) return;
  const viewport = window.visualViewport;
  const viewportWidth = viewport?.width || window.innerWidth;
  const viewportHeight = viewport?.height || window.innerHeight;
  const rect = panel.getBoundingClientRect();
  const safe = 8;
  const left = Math.max(safe, Math.min(parseFloat(panel.style.left) || rect.left, viewportWidth - rect.width - safe));
  const top = Math.max(safe, Math.min(parseFloat(panel.style.top) || rect.top, viewportHeight - Math.min(rect.height, viewportHeight - safe * 2) - safe));
  panel.style.left = `${left}px`;
  panel.style.top = `${top}px`;
}

function makeFloatingPanel(panel, { id, titleKey }) {
  panel.classList.add('floating-window');
  panel.dataset.floatingPanel = id;
  const bar = document.createElement('div');
  bar.className = 'floating-window-bar';
  bar.innerHTML = `
    <span class="floating-window-grip" aria-hidden="true">⠿</span>
    <span class="floating-window-title"></span>
    <span class="floating-window-actions">
      <button type="button" class="floating-window-minimize" aria-expanded="true">−</button>
      <button type="button" class="floating-window-close">×</button>
    </span>`;
  panel.prepend(bar);

  const restore = document.createElement('button');
  restore.type = 'button';
  restore.className = 'floating-panel-restore';
  restore.hidden = true;
  floatingPanelDock.append(restore);

  const item = {
    panel,
    id,
    titleKey,
    title: bar.querySelector('.floating-window-title'),
    minimize: bar.querySelector('.floating-window-minimize'),
    close: bar.querySelector('.floating-window-close'),
    restore,
  };
  floatingPanels.push(item);

  item.minimize.addEventListener('click', () => toggleFloatingPanel(item));
  item.close.addEventListener('click', () => closeFloatingPanel(item));
  restore.addEventListener('click', () => restoreFloatingPanel(item));

  bar.addEventListener('pointerdown', (event) => {
    if (!compactLayoutQuery.matches || event.target.closest('button')) return;
    const rect = panel.getBoundingClientRect();
    const originX = event.clientX;
    const originY = event.clientY;
    const originLeft = rect.left;
    const originTop = rect.top;
    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.width = `${rect.width}px`;
    panel.style.transform = 'none';
    panel.style.zIndex = String(++floatingZIndex);
    panel.classList.add('is-floating-dragged');
    bar.setPointerCapture(event.pointerId);

    const move = (moveEvent) => {
      const viewport = window.visualViewport;
      const viewportWidth = viewport?.width || window.innerWidth;
      const viewportHeight = viewport?.height || window.innerHeight;
      const width = panel.getBoundingClientRect().width;
      const height = Math.min(panel.getBoundingClientRect().height, viewportHeight - 16);
      panel.style.left = `${Math.max(8, Math.min(originLeft + moveEvent.clientX - originX, viewportWidth - width - 8))}px`;
      panel.style.top = `${Math.max(8, Math.min(originTop + moveEvent.clientY - originY, viewportHeight - height - 8))}px`;
    };
    const end = () => {
      panel.classList.remove('is-floating-dragged');
      bar.removeEventListener('pointermove', move);
      bar.removeEventListener('pointerup', end);
      bar.removeEventListener('pointercancel', end);
      fitFloatingPanel(panel);
    };
    bar.addEventListener('pointermove', move);
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end);
  });
}

makeFloatingPanel(document.querySelector('.view-toolbar'), { id: 'views', titleKey: 'view' });
makeFloatingPanel(layerPanel, { id: 'settings', titleKey: 'filters' });
makeFloatingPanel(selectionCard, { id: 'selection', titleKey: 'detailsPanel' });
makeFloatingPanel(natalPanel, { id: 'natal', titleKey: 'natalReading' });
makeFloatingPanel(document.querySelector('.result-copy'), { id: 'birth-data', titleKey: 'birthDataPanel' });

const dome = new SkyDome(document.querySelector('.sky-canvas'), {
  onError: () => {
    webglError.hidden = false;
    webglError.textContent = copy[state.language].webglError;
  },
  onSelect: (selection) => updateSelection(selection),
  onHover: (selection, event) => updateTooltip(selection, event),
});
dome.setLayers(state.layers, state.density);
initializeSwissEphemeris().catch(() => {});

function selectionTitle(selection) {
  if (!selection) return '';
  if (selection.type === 'constellation') return state.language === 'en' ? selection.nameEn : selection.name;
  if (selection.type === 'planet') return copy[state.language].bodies[selection.id] || selection.label || selection.id;
  if (selection.type === 'angle') return copy[state.language].angles[selection.id] || selection.label || selection.id;
  if (selection.type === 'aspect') {
    const text = copy[state.language];
    return `${text.bodies[selection.from] || selection.from} ${text[selection.aspectType] || selection.aspectType} ${text.bodies[selection.to] || selection.to}`;
  }
  return selection.name || selection.designation || `HIP ${selection.hip || selection.id}`;
}

function chironSvg(className = 'chiron-icon') {
  return `<svg class="${className}" viewBox="0 0 64 64" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="28" cy="43" r="12"/><path d="M28 31V10M28 20l15-10M28 20l15 12"/></svg>`;
}

function bodyGlyph(name, symbol, className = 'natal-planet-symbol') {
  return name === 'Chiron'
    ? `<span class="${className}" data-body="${name}">${chironSvg()}</span>`
    : `<span class="${className}" data-body="${name}">${symbol}</span>`;
}

function degree(value) {
  return Number.isFinite(value) ? `${value.toFixed(1)}°` : '—';
}

function zodiacDegree(value) {
  if (!Number.isFinite(value)) return '—';
  const normalized = ((value % 360) + 360) % 360;
  let signIndex = Math.floor(normalized / 30);
  let minutes = Math.round((normalized % 30) * 60);
  if (minutes === 1800) {
    signIndex = (signIndex + 1) % 12;
    minutes = 0;
  }
  const [, sign] = zodiac[state.language][signIndex];
  return `${sign} ${Math.floor(minutes / 60)}° ${String(minutes % 60).padStart(2, '0')}′`;
}

function updateSelection(selection) {
  if (!selection) {
    selectionCard.hidden = true;
    selectionCard.classList.remove('is-expanded');
    selectionDetails.replaceChildren();
    if (compactLayoutQuery.matches) updateNatalPanel();
    return;
  }
  if (compactLayoutQuery.matches) natalPanel.hidden = true;
  const selectionPanel = floatingPanels.find((item) => item.id === 'selection');
  if (selectionPanel) restoreFloatingPanel(selectionPanel);
  const text = copy[state.language];
  selectionCard.hidden = false;
  selectionDetails.replaceChildren();
  const isPlanetReading = selection.type === 'planet' && state.view === 'natal' && Number.isFinite(selection.signIndex);
  const isAngleReading = selection.type === 'angle' && state.view === 'natal' && Number.isFinite(selection.signIndex);
  const isAspectReading = selection.type === 'aspect';
  selectionCard.classList.toggle('is-expanded', isPlanetReading || isAngleReading || isAspectReading);
  if (selection.type === 'planet' && selection.name === 'Chiron') selectionGlyph.innerHTML = chironSvg('selection-chiron-icon');
  else selectionGlyph.textContent = selection.type === 'planet' ? selection.symbol : selection.type === 'angle' ? selection.symbol : selection.type === 'constellation' ? '⌁' : selection.type === 'aspect' ? selection.symbol : '✦';
  selectionKind.textContent = isPlanetReading || isAngleReading ? text.quickReading : text[selection.type];
  selectionName.textContent = selectionTitle(selection);
  const facts = [];
  if (selection.type === 'star' && Number.isFinite(selection.magnitude)) facts.push(`${text.magnitude} ${selection.magnitude.toFixed(2)}`);
  if (['disc', 'natal'].includes(state.view) && Number.isFinite(selection.eclipticLongitude)) {
    const longitude = ((selection.eclipticLongitude % 360) + 360) % 360;
    const [, sign] = zodiac[state.language][Math.floor(longitude / 30)];
    facts.push(`${sign} ${(longitude % 30).toFixed(1)}°`);
  }
  if (state.view === 'natal' && Number.isFinite(selection.house)) facts.push(`${text.house} ${selection.house}`);
  if (isAspectReading) facts.push(`${text.orb} ${selection.exactness.toFixed(1)}°`);
  if (Number.isFinite(selection.altitude)) facts.push(`${text.altitude} ${degree(selection.altitude)}`);
  if (Number.isFinite(selection.azimuth)) facts.push(`${text.azimuth} ${degree(selection.azimuth)}`);
  if (isPlanetReading) {
    selectionMeta.innerHTML = `${zodiacSvg(selection.signIndex, { className: 'selection-sign-icon' })}<span>${facts.join(' · ')}</span>`;
    const [, signName] = zodiac[state.language][selection.signIndex];
    const houseIndex = Math.max(0, (selection.house || 1) - 1);
    selectionDetails.innerHTML = `
      <article><h4>${text.bodies[selection.name] || selection.name}</h4><p>${text.planetMeanings[selection.name] || ''}</p></article>
      <article><h4>${signName}</h4><p>${text.signMeanings[selection.signIndex]}</p></article>
      <article><h4>${text.house} ${selection.house}</h4><p>${text.houseMeanings[houseIndex]}</p></article>`;
  } else if (isAngleReading) {
    selectionMeta.innerHTML = `${zodiacSvg(selection.signIndex, { className: 'selection-sign-icon' })}<span>${facts.join(' · ')}</span>`;
    selectionDetails.innerHTML = `<article><h4>${text.angles[selection.id]}</h4><p>${text.angleMeanings[selection.id]}</p></article>`;
  } else if (isAspectReading) {
    selectionMeta.textContent = facts.join(' · ');
    selectionDetails.innerHTML = `<article><p>${text.aspectMeanings[selection.aspectType] || ''}</p></article>`;
  } else selectionMeta.textContent = facts.join(' · ');
}

function updateTooltip(selection, event) {
  if (!selection || state.mode !== 'result') {
    skyTooltip.hidden = true;
    return;
  }
  const stageRect = document.querySelector('.sky-stage').getBoundingClientRect();
  skyTooltip.textContent = selectionTitle(selection);
  skyTooltip.style.left = `${event.clientX - stageRect.left + 14}px`;
  skyTooltip.style.top = `${event.clientY - stageRect.top + 14}px`;
  skyTooltip.hidden = false;
}

function setCopy() {
  const text = copy[state.language];
  document.documentElement.lang = state.language === 'pt' ? 'pt-BR' : 'en';
  document.title = 'Celeste · Stargaze';
  document.querySelectorAll('[data-copy]').forEach((node) => {
    node.textContent = text[node.dataset.copy] ?? '';
  });
  document.querySelectorAll('[data-placeholder]').forEach((node) => {
    node.placeholder = text[node.dataset.placeholder] ?? '';
  });
  document.querySelectorAll('[data-copy-aria]').forEach((node) => {
    node.setAttribute('aria-label', text[node.dataset.copyAria] ?? '');
  });
  document.querySelectorAll('[data-language]').forEach((button) => {
    const active = button.dataset.language === state.language;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  document.querySelector('.sky-stage').setAttribute('aria-label', state.language === 'pt' ? 'Mapa celeste interativo' : 'Interactive celestial map');
  document.querySelector('.layer-panel').setAttribute('aria-label', text.filters);
  document.querySelector('.segmented').setAttribute('aria-label', text.density);
  updateFloatingPanelCopy();
  dome.updateCompass({ north: text.north, east: text.east, south: text.south, west: text.west, zenith: text.zenith, nadir: text.nadir });
  webglError.textContent = text.webglError;
  updateResultCopy();
  if (state.sky) dome.renderSky(state.sky, { language: state.language, bodyNames: text.bodies });
  updateViewSpecificCopy();
  updateNatalPanel();
  updateSelection(dome.selection);
}

function applyTextSize({ persist = true } = {}) {
  state.textSize = Math.max(-1, Math.min(3, state.textSize));
  document.documentElement.style.setProperty('--text-adjustment', `${state.textSize}px`);
  textSizeButtons.forEach((button) => {
    const decrease = button.dataset.textSize === 'decrease';
    button.disabled = decrease ? state.textSize <= -1 : state.textSize >= 3;
  });
  if (!persist) return;
  try { window.localStorage.setItem('celeste-text-size', String(state.textSize)); } catch { /* Storage may be unavailable. */ }
}

function updateViewSpecificCopy() {
  const text = copy[state.language];
  document.querySelector('.symbolic-note').textContent = state.view === 'natal'
    ? text.natalLayerNote
    : state.view === 'disc' ? text.discLayerNote : text.symbolicNote;
  document.querySelector('.stage-caption [data-copy="astronomyNote"]').textContent = state.view === 'natal'
    ? text.natalAstronomyNote
    : state.view === 'disc' ? text.discAstronomyNote : text.astronomyNote;
}

function renderBalance(chart, type, keys) {
  const container = document.querySelector(`[data-balance="${type}"]`);
  const bar = container.querySelector('.stacked-bar');
  const readout = container.querySelector('.balance-readout');
  const legend = container.querySelector('.balance-legend');
  const counts = Object.fromEntries(keys.map((key) => [key, 0]));
  chart.planets.slice(0, 10).forEach((planet) => {
    const category = ZODIAC_DATA[planet.signIndex]?.[type === 'elements' ? 'element' : 'modality'];
    if (category in counts) counts[category] += 1;
  });
  const total = Object.values(counts).reduce((sum, value) => sum + value, 0) || 1;
  const percentages = Object.fromEntries(keys.map((key) => [
    key, Math.round((counts[key] / total) * 100),
  ]));
  bar.innerHTML = keys.map((key) => {
    const percent = (counts[key] / total) * 100;
    const label = `${copy[state.language][key]} ${percentages[key]}%`;
    return `<button type="button" data-category="${key}" style="width:${percent}%" title="${label}" aria-label="${label}" aria-pressed="false"></button>`;
  }).join('');
  legend.innerHTML = keys.map((key) => {
    const label = `${copy[state.language][key]} ${percentages[key]}%`;
    return `<button type="button" data-category="${key}" aria-label="${label}" aria-pressed="false"><i></i>${copy[state.language][key]} <strong>${percentages[key]}%</strong></button>`;
  }).join('');

  let pinnedCategory = null;
  const showCategory = (key) => {
    container.querySelectorAll('[data-category]').forEach((item) => {
      const active = Boolean(key) && item.dataset.category === key;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-pressed', String(active && pinnedCategory === key));
    });
    readout.textContent = key ? `${copy[state.language][key]} · ${percentages[key]}%` : '';
  };
  keys.forEach((key) => {
    container.querySelectorAll(`[data-category="${key}"]`).forEach((item) => {
      item.addEventListener('pointerenter', () => showCategory(key));
      item.addEventListener('pointerleave', () => showCategory(pinnedCategory));
      item.addEventListener('focus', () => showCategory(key));
      item.addEventListener('blur', () => showCategory(pinnedCategory));
      item.addEventListener('click', () => {
        pinnedCategory = pinnedCategory === key ? null : key;
        showCategory(pinnedCategory);
      });
    });
  });
}

function updateNatalPanel() {
  const chart = state.sky?.natalChart;
  natalPanel.hidden = state.view !== 'natal' || !chart || state.mode !== 'result';
  if (!chart) return;
  const text = copy[state.language];
  natalModel.textContent = `${text.natalModel} · ${chart.engine} ${chart.version}`;
  natalCaveat.textContent = state.unknownTime ? text.natalTimeWarning : text.natalCaveat;
  natalList.replaceChildren();
  const angles = [
    {
      type: 'angle', id: 'Ascendant', name: 'Ascendant', symbol: 'ASC',
      eclipticLongitude: chart.ascendant, signIndex: Math.floor(chart.ascendant / 30), house: 1,
    },
    {
      type: 'angle', id: 'Midheaven', name: 'Midheaven', symbol: 'MC',
      eclipticLongitude: chart.midheaven, signIndex: Math.floor(chart.midheaven / 30), house: 10,
    },
  ];
  const natalItems = [
    ...chart.planets.slice(0, 2), angles[0],
    ...chart.planets.slice(2, 7), angles[1],
    ...chart.planets.slice(7),
  ];
  natalItems.forEach((planet) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.dataset.body = planet.name;
    const isAngle = planet.type === 'angle';
    row.innerHTML = `
      ${bodyGlyph(planet.name, planet.symbol)}
      <span class="natal-planet-name">${isAngle ? text.angles[planet.id] : text.bodies[planet.name] || planet.name}</span>
      <span class="natal-position">${zodiacSvg(planet.signIndex, { className: 'zodiac-row-icon' })}<span>${zodiacDegree(planet.eclipticLongitude)}${planet.retrograde ? ' ℞' : ''}</span></span>
      <span class="natal-house">${text.house} ${planet.house}</span>`;
    row.addEventListener('click', () => {
      dome.focusSelection({
        type: isAngle ? 'angle' : 'planet', id: planet.id || planet.name, ...planet, display: planet,
        label: isAngle ? text.angles[planet.id] : text.bodies[planet.name] || planet.name,
      });
    });
    natalList.append(row);
  });

  renderBalance(chart, 'elements', ['fire', 'earth', 'air', 'water']);
  renderBalance(chart, 'modalities', ['cardinal', 'fixed', 'mutable']);

  aspectCount.textContent = ` ${chart.aspects.length}`;
  aspectLegend.innerHTML = `
    <span data-family="harmonic">${text.harmonic}</span>
    <span data-family="tense">${text.tense}</span>
    <span data-family="neutral">${text.conjunction}</span>`;
  aspectList.replaceChildren();
  const aspectOrder = ['conjunction', 'opposition', 'square', 'trine', 'sextile', 'quincunx'];
  const sortedAspects = [...chart.aspects].sort((a, b) => (
    aspectOrder.indexOf(a.type) - aspectOrder.indexOf(b.type) || a.exactness - b.exactness
  ));
  let previousAspectType = '';
  sortedAspects.forEach((aspect) => {
    if (aspect.type !== previousAspectType) {
      const heading = document.createElement('p');
      heading.className = 'aspect-group-label';
      heading.textContent = text[aspect.type] || aspect.type;
      aspectList.append(heading);
      previousAspectType = aspect.type;
    }
    const row = document.createElement('button');
    row.type = 'button';
    row.className = 'aspect-row';
    row.dataset.family = aspect.family;
    row.innerHTML = `
      <span>${text.bodies[aspect.from] || aspect.from}</span>
      <strong title="${text[aspect.type] || aspect.type}">${aspect.symbol}</strong>
      <span>${text.bodies[aspect.to] || aspect.to}</span>
      <small>${aspect.exactness.toFixed(1)}°</small>`;
    row.addEventListener('click', () => {
      const from = chart.planets.find((planet) => planet.name === aspect.from);
      const to = chart.planets.find((planet) => planet.name === aspect.to);
      dome.focusAspect({
        ...aspect,
        type: 'aspect',
        id: `${aspect.from}-${aspect.type}-${aspect.to}`,
        aspectType: aspect.type,
        fromDisplay: from,
        toDisplay: to,
      });
    });
    aspectList.append(row);
  });
}

function updateResultCopy() {
  if (!state.location || !state.date) return;
  const text = copy[state.language];
  const placeParts = [state.location.name, state.location.admin1, state.location.country].filter(Boolean);
  document.querySelector('.result-place').textContent = [...new Set(placeParts)].join(' · ');
  document.querySelector('.result-date').textContent = formatDate(state.date, state.language);
  document.querySelector('.result-time').textContent = state.unknownTime
    ? text.estimatedTime
    : `${state.time} · ${text.exactTime.toLowerCase()}`;
}

function showLocationMessage(message) {
  locationStatus.textContent = message;
}

function locationLabel(place) {
  return [...new Set([place.name, place.admin1, place.country].filter(Boolean))].join(', ');
}

function selectLocation(place) {
  state.location = {
    name: place.name,
    admin1: place.admin1,
    country: place.country,
    latitude: place.latitude,
    longitude: place.longitude,
    elevation: place.elevation || 0,
    timezone: place.timezone || 'UTC',
  };
  locationInput.value = locationLabel(place);
  locationInput.dataset.selected = 'true';
  locationResults.hidden = true;
  locationResults.replaceChildren();
  showLocationMessage('');
  formError.textContent = '';
}

function localInputsInZone(date, timeZone) {
  const values = {};
  new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(date).forEach((part) => {
    if (part.type !== 'literal') values[part.type] = part.value;
  });
  return {
    date: `${values.year}-${values.month}-${values.day}`,
    time: `${values.hour}:${values.minute}`,
  };
}

function currentLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) reject(new Error('geolocation unavailable'));
    else navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: false,
      timeout: 9000,
      maximumAge: 300000,
    });
  });
}

function showLocationResults(places) {
  locationResults.replaceChildren();
  if (!places.length) {
    locationResults.hidden = false;
    const empty = document.createElement('p');
    empty.className = 'empty-result';
    empty.textContent = copy[state.language].noPlaces;
    locationResults.append(empty);
    return;
  }
  places.forEach((place) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.role = 'option';
    button.innerHTML = `<span>${place.name}</span><small>${[place.admin1, place.country].filter(Boolean).join(' · ')}</small>`;
    button.addEventListener('click', () => selectLocation(place));
    locationResults.append(button);
  });
  locationResults.hidden = false;
}

async function searchLocations(query) {
  searchRequest?.abort();
  searchRequest = new AbortController();
  showLocationMessage(copy[state.language].searching);
  try {
    const params = new URLSearchParams({
      name: query,
      count: '7',
      language: state.language === 'pt' ? 'pt' : 'en',
      format: 'json',
    });
    const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${params}`, { signal: searchRequest.signal });
    if (!response.ok) throw new Error(`Geocoding returned ${response.status}`);
    const payload = await response.json();
    showLocationMessage('');
    showLocationResults(payload.results || []);
  } catch (error) {
    if (error.name === 'AbortError') return;
    locationResults.hidden = true;
    showLocationMessage(copy[state.language].locationError);
  }
}

locationInput.addEventListener('input', () => {
  state.location = null;
  delete locationInput.dataset.selected;
  clearTimeout(searchTimer);
  const query = locationInput.value.trim();
  if (query.length < 2) {
    locationResults.hidden = true;
    showLocationMessage('');
    return;
  }
  searchTimer = setTimeout(() => searchLocations(query), 320);
});

locationInput.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') locationResults.hidden = true;
  if (event.key === 'ArrowDown' && !locationResults.hidden) {
    event.preventDefault();
    locationResults.querySelector('button')?.focus();
  }
});

document.addEventListener('pointerdown', (event) => {
  if (!event.target.closest('.location-field')) locationResults.hidden = true;
});

form.addEventListener('submit', (event) => {
  event.preventDefault();
  formError.textContent = '';
  if (!state.location) {
    formError.textContent = copy[state.language].errorLocation;
    locationInput.focus();
    return;
  }
  if (!dateInput.value) {
    formError.textContent = copy[state.language].errorDate;
    dateInput.focus();
    return;
  }
  state.date = dateInput.value;
  state.unknownTime = !timeInput.value;
  state.time = timeInput.value || '12:00';
  generateSky();
});

nowButton.addEventListener('click', async () => {
  formError.textContent = '';
  nowButton.disabled = true;
  nowButton.querySelector('[data-copy]').textContent = copy[state.language].locating;
  try {
    if (!state.location) {
      const position = await currentLocation();
      selectLocation({
        name: copy[state.language].currentLocation,
        country: '',
        admin1: '',
        elevation: position.coords.altitude || 0,
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
      });
    }
    const now = new Date();
    const localNow = localInputsInZone(now, state.location.timezone);
    dateInput.value = localNow.date;
    timeInput.value = localNow.time;
    state.unknownTime = false;
    state.date = dateInput.value;
    state.time = timeInput.value;
    generateSky();
  } catch (error) {
    formError.textContent = copy[state.language].geolocationError;
  } finally {
    nowButton.disabled = false;
    nowButton.querySelector('[data-copy]').textContent = copy[state.language].skyNow;
  }
});

function generateSky({ quiet = false, preserveView = false } = {}) {
  const requestId = ++generationRequestId;
  const request = {
    date: state.date,
    time: state.time,
    location: { ...state.location },
  };
  if (!quiet) {
    experience.classList.add('is-loading');
    submitButton.disabled = true;
  }
  window.setTimeout(async () => {
    try {
      const date = localDateToUtc(request.date, request.time, request.location.timezone);
      const sky = calculateSky({
        date,
        latitude: request.location.latitude,
        longitude: request.location.longitude,
        elevation: request.location.elevation,
      });
      const swissChart = await calculateSwissChart({
        date,
        latitude: request.location.latitude,
        longitude: request.location.longitude,
        elevation: request.location.elevation,
      });
      if (requestId !== generationRequestId) return;
      sky.natalChart = swissChart;
      sky.planets = swissChart.observedPlanets;
      sky.symbolicHouses = swissChart.observedHouses;
      state.sky = sky;
      if (!preserveView) state.view = 'natal';
      document.querySelectorAll('[data-view]').forEach((item) => item.classList.toggle('is-active', item.dataset.view === state.view));
      dome.setView(state.view);
      dome.renderSky(state.sky, { language: state.language, bodyNames: copy[state.language].bodies });
      updateResultCopy();
      state.mode = 'result';
      experience.dataset.mode = 'result';
      floatingPanels.forEach((item) => {
        item.panel.removeAttribute('style');
        item.panel.classList.remove('is-panel-closed', 'is-minimized', 'is-floating-dragged');
        item.panel.removeAttribute('data-panel-closed');
        item.restore.hidden = true;
        item.minimize.setAttribute('aria-expanded', 'true');
      });
      layerPanel.classList.remove('is-open');
      settingsButton.setAttribute('aria-expanded', 'false');
      updateNatalPanel();
    } catch (error) {
      if (requestId !== generationRequestId) return;
      formError.textContent = copy[state.language].swissError;
      state.mode = 'form';
      experience.dataset.mode = 'form';
      console.error(error);
    } finally {
      if (requestId !== generationRequestId) return;
      experience.classList.remove('is-loading');
      submitButton.disabled = false;
    }
  }, quiet ? 0 : 540);
}

document.querySelector('.edit-button').addEventListener('click', () => {
  state.mode = 'form';
  experience.dataset.mode = 'form';
  updateNatalPanel();
  window.setTimeout(() => locationInput.focus(), 120);
});

document.querySelectorAll('[data-language]').forEach((button) => {
  button.addEventListener('click', () => {
    state.language = button.dataset.language;
    setCopy();
  });
});

textSizeButtons.forEach((button) => {
  button.addEventListener('click', () => {
    state.textSize += button.dataset.textSize === 'increase' ? 1 : -1;
    applyTextSize();
  });
});

document.querySelectorAll('[data-layer]').forEach((button) => {
  button.addEventListener('click', () => {
    const layer = button.dataset.layer;
    state.layers[layer] = !state.layers[layer];
    button.classList.toggle('is-on', state.layers[layer]);
    button.setAttribute('aria-pressed', String(state.layers[layer]));
    dome.setLayers(state.layers, state.density);
  });
});

document.querySelectorAll('[data-density]').forEach((button) => {
  button.addEventListener('click', () => {
    state.density = button.dataset.density;
    document.querySelectorAll('[data-density]').forEach((item) => item.classList.toggle('is-active', item === button));
    dome.setLayers(state.layers, state.density);
  });
});

document.querySelectorAll('[data-view]').forEach((button) => {
  button.addEventListener('click', () => {
    state.view = button.dataset.view;
    document.querySelectorAll('[data-view]').forEach((item) => item.classList.toggle('is-active', item === button));
    dome.setView(state.view);
    updateViewSpecificCopy();
    updateNatalPanel();
  });
});

settingsButton.addEventListener('click', () => {
  const open = !layerPanel.classList.contains('is-open');
  const settingsPanel = floatingPanels.find((item) => item.id === 'settings');
  if (open && settingsPanel) restoreFloatingPanel(settingsPanel);
  layerPanel.classList.toggle('is-open', open);
  settingsButton.setAttribute('aria-expanded', String(open));
});

document.querySelector('[data-action="close-settings"]').addEventListener('click', () => {
  layerPanel.classList.remove('is-open');
  settingsButton.setAttribute('aria-expanded', 'false');
  settingsButton.focus();
});

document.querySelector('.clear-selection').addEventListener('click', () => dome.setSelection(null));

compactLayoutQuery.addEventListener?.('change', () => {
  if (!compactLayoutQuery.matches) {
    floatingPanels.forEach((item) => {
      item.panel.removeAttribute('style');
      item.panel.classList.remove('is-panel-closed', 'is-minimized', 'is-floating-dragged');
      item.panel.removeAttribute('data-panel-closed');
      item.restore.hidden = true;
    });
  }
  if (compactLayoutQuery.matches && dome.selection) natalPanel.hidden = true;
  else updateNatalPanel();
});

window.addEventListener('resize', () => floatingPanels.forEach(({ panel }) => fitFloatingPanel(panel)));
window.visualViewport?.addEventListener('resize', () => floatingPanels.forEach(({ panel }) => fitFloatingPanel(panel)));

// A quiet, real sky keeps the first screen alive before personal data is entered.
const demoDate = new Date();
demoDate.setUTCHours(0, 0, 0, 0);
const demoSky = calculateSky({ date: demoDate, latitude: -23.5505, longitude: -46.6333, elevation: 760 });
dome.renderSky(demoSky, { language: state.language, bodyNames: copy.pt.bodies });
calculateSwissChart({ date: demoDate, latitude: -23.5505, longitude: -46.6333, elevation: 760 })
  .then((chart) => {
    if (state.mode !== 'form') return;
    demoSky.natalChart = chart;
    demoSky.planets = chart.observedPlanets;
    demoSky.symbolicHouses = chart.observedHouses;
    dome.renderSky(demoSky, { language: state.language, bodyNames: copy[state.language].bodies });
  })
  .catch(() => {});

try {
  const savedTextSize = Number(window.localStorage.getItem('celeste-text-size'));
  if (Number.isInteger(savedTextSize)) state.textSize = savedTextSize;
} catch { /* Use the default size when storage is unavailable. */ }
applyTextSize({ persist: false });
setCopy();

window.addEventListener('beforeunload', () => dome.destroy(), { once: true });
