import * as Astronomy from 'astronomy-engine';
import starsCatalog from './data/stars.6.json';
import starNames from './data/starnames.6.json';
import constellationLines from './data/constellations.lines.json';
import constellationLabels from './data/constellations.json';

function partsInZone(date, timeZone) {
  const values = {};
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  parts.forEach((part) => {
    if (part.type !== 'literal') values[part.type] = Number(part.value);
  });
  return values;
}

export function localDateToUtc(dateValue, timeValue, timeZone) {
  const [year, month, day] = dateValue.split('-').map(Number);
  const [hour, minute] = timeValue.split(':').map(Number);
  const target = Date.UTC(year, month - 1, day, hour, minute, 0);
  let guess = target;

  for (let index = 0; index < 3; index += 1) {
    const zoned = partsInZone(new Date(guess), timeZone);
    const represented = Date.UTC(
      zoned.year, zoned.month - 1, zoned.day,
      zoned.hour, zoned.minute, zoned.second,
    );
    guess += target - represented;
  }
  return new Date(guess);
}

function precessedHorizon(date, observer, raDegrees, decDegrees, rotation) {
  const j2000 = Astronomy.VectorFromSphere(
    new Astronomy.Spherical(decDegrees, ((raDegrees % 360) + 360) % 360, 1),
    date,
  );
  const ofDate = Astronomy.RotateVector(rotation, j2000);
  const equator = Astronomy.EquatorFromVector(ofDate);
  return Astronomy.Horizon(date, observer, equator.ra, equator.dec, 'normal');
}

function eclipticFromJ2000(date, raDegrees, decDegrees) {
  const vector = Astronomy.VectorFromSphere(
    new Astronomy.Spherical(decDegrees, ((raDegrees % 360) + 360) % 360, 1),
    date,
  );
  const ecliptic = Astronomy.Ecliptic(vector);
  return { eclipticLongitude: ecliptic.elon, eclipticLatitude: ecliptic.elat };
}

function toSkyPoint(horizontal) {
  return { altitude: horizontal.altitude, azimuth: horizontal.azimuth };
}

export function calculateSky({ date, latitude, longitude, elevation = 0 }) {
  const observer = new Astronomy.Observer(latitude, longitude, elevation);
  const rotation = Astronomy.Rotation_EQJ_EQD(date);

  const stars = starsCatalog.features.map((feature) => {
    const [ra, dec] = feature.geometry.coordinates;
    const horizontal = precessedHorizon(date, observer, ra, dec, rotation);
    const identity = starNames[feature.id] || {};
    return {
      id: feature.id,
      name: identity.name || '',
      designation: identity.designation || identity.hip || `HIP ${feature.id}`,
      constellation: identity.constellation || '',
      magnitude: Number(feature.properties.mag),
      bv: Number(feature.properties.bv),
      catalogLongitude: ra,
      catalogLatitude: dec,
      ...eclipticFromJ2000(date, ra, dec),
      ...toSkyPoint(horizontal),
    };
  });

  const constellationById = new Map();
  constellationLines.features.forEach((feature) => {
    const runs = feature.geometry.coordinates.map((run) => run.map(([ra, dec]) => {
      const horizontal = precessedHorizon(date, observer, ra, dec, rotation);
      return {
        catalogLongitude: ra,
        catalogLatitude: dec,
        ...toSkyPoint(horizontal),
        ...eclipticFromJ2000(date, ra, dec),
      };
    }));
    constellationById.set(feature.id, runs);
  });

  const labels = constellationLabels.features.map((feature) => {
    const [ra, dec] = feature.geometry.coordinates;
    const horizontal = precessedHorizon(date, observer, ra, dec, rotation);
    return {
      id: feature.id,
      name: feature.properties.name,
      nameEn: feature.properties.name,
      rank: Number(feature.properties.rank || 3),
      ...eclipticFromJ2000(date, ra, dec),
      ...toSkyPoint(horizontal),
    };
  });

  const labelById = new Map(labels.map((label) => [label.id, label]));
  return {
    stars,
    constellations: constellationById,
    labels,
    labelById,
    planets: [],
    symbolicHouses: null,
  };
}
