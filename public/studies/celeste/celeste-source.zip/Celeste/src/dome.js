import * as THREE from 'three';
import { drawZodiacGlyph } from './zodiac-icons.js';
const RADIUS = 4.6;
const TAU = Math.PI * 2;
const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
function normalizedPoint(point) {
  return point;
}

function spherePosition(point, radius = RADIUS) {
  const alt = THREE.MathUtils.degToRad(THREE.MathUtils.clamp(point.altitude, -90, 90));
  const az = THREE.MathUtils.degToRad(point.azimuth);
  const horizontal = Math.cos(alt) * radius;
  return new THREE.Vector3(
    Math.sin(az) * horizontal,
    Math.sin(alt) * radius,
    -Math.cos(az) * horizontal,
  );
}

function discPosition(point, radius = RADIUS) {
  const longitude = Number.isFinite(point.eclipticLongitude) ? point.eclipticLongitude : point.azimuth;
  const latitude = Number.isFinite(point.eclipticLatitude) ? point.eclipticLatitude : point.altitude;
  const angle = THREE.MathUtils.degToRad(longitude);
  const radial = ((90 - THREE.MathUtils.clamp(latitude, -90, 90)) / 180) * radius;
  return new THREE.Vector3(Math.sin(angle) * radial, 0, -Math.cos(angle) * radial);
}

function natalPosition(point, radius = 2.78, ascendant = 0) {
  const longitude = Number.isFinite(point.eclipticLongitude) ? point.eclipticLongitude : 0;
  const angle = THREE.MathUtils.degToRad(ascendant - longitude + 270);
  return new THREE.Vector3(Math.sin(angle) * radius, 0, -Math.cos(angle) * radius);
}

function makeLine(points, material) {
  return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), material);
}

function makeGlowTube(points, color, radius = .017, opacity = .2) {
  if (points.length < 2) return null;
  const curve = new THREE.CatmullRomCurve3(points, false, 'catmullrom', .18);
  const geometry = new THREE.TubeGeometry(curve, Math.max(12, points.length * 5), radius, 6, false);
  const material = new THREE.MeshBasicMaterial({
    color,
    transparent: true,
    opacity,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  return new THREE.Mesh(geometry, material);
}

function makeStructureTube(points, color, radius = .006, opacity = .24) {
  if (points.length < 2) return null;
  const curve = new THREE.CatmullRomCurve3(points, false, 'catmullrom', .18);
  const geometry = new THREE.TubeGeometry(curve, Math.max(8, points.length * 4), radius, 5, false);
  const material = rememberOpacity(new THREE.MeshBasicMaterial({
    color,
    transparent: true,
    opacity,
    depthWrite: false,
  }), opacity);
  return new THREE.Mesh(geometry, material);
}

function geometryPoints(line) {
  const attribute = line.geometry?.getAttribute('position');
  if (!attribute) return [];
  return Array.from({ length: attribute.count }, (_, index) => new THREE.Vector3().fromBufferAttribute(attribute, index));
}

function angularDistanceDegrees(first, second) {
  if (![first.catalogLongitude, first.catalogLatitude, second.catalogLongitude, second.catalogLatitude]
    .every(Number.isFinite)) return Infinity;
  const longitudeA = THREE.MathUtils.degToRad(first.catalogLongitude);
  const latitudeA = THREE.MathUtils.degToRad(first.catalogLatitude);
  const longitudeB = THREE.MathUtils.degToRad(second.catalogLongitude);
  const latitudeB = THREE.MathUtils.degToRad(second.catalogLatitude);
  const cosine = Math.sin(latitudeA) * Math.sin(latitudeB)
    + Math.cos(latitudeA) * Math.cos(latitudeB) * Math.cos(longitudeA - longitudeB);
  return THREE.MathUtils.radToDeg(Math.acos(THREE.MathUtils.clamp(cosine, -1, 1)));
}

function rememberOpacity(material, opacity = material.opacity ?? 1) {
  material.userData.baseOpacity = opacity;
  return material;
}

function makeTextTexture(text, {
  font = '600 36px "Space Mono", monospace',
  color = '#e7cf91',
  width = 480,
  height = 104,
} = {}) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, width, height);
  context.fillStyle = color;
  context.font = font;
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.shadowColor = 'rgba(5, 9, 20, .9)';
  context.shadowBlur = 10;
  context.fillText(text, width / 2, height / 2);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  return texture;
}

function makeZodiacTexture(index) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const context = canvas.getContext('2d');
  drawZodiacGlyph(context, index, { color: '#e7cf91', size: 128, padding: 11 });
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  return texture;
}

function makeStarTexture(points = 4, warm = true) {
  const size = 192;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext('2d');
  context.translate(size / 2, size / 2);

  const gradient = context.createRadialGradient(0, 0, 1, 0, 0, 72);
  gradient.addColorStop(0, warm ? 'rgba(255,242,193,1)' : 'rgba(225,235,255,1)');
  gradient.addColorStop(.3, warm ? 'rgba(229,188,102,.5)' : 'rgba(151,178,244,.46)');
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  context.fillStyle = gradient;
  context.beginPath();
  context.arc(0, 0, 72, 0, TAU);
  context.fill();

  context.beginPath();
  for (let index = 0; index < points * 2; index += 1) {
    const angle = -Math.PI / 2 + (index * Math.PI) / points;
    const radius = index % 2 === 0 ? 48 : 13;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    if (index === 0) context.moveTo(x, y);
    else context.lineTo(x, y);
  }
  context.closePath();
  context.fillStyle = warm ? '#e4c475' : '#dce5ff';
  context.fill();
  context.strokeStyle = warm ? 'rgba(255,241,193,.7)' : 'rgba(229,235,255,.72)';
  context.lineWidth = 1.7;
  context.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  return texture;
}

function makePlanetTexture(color = '#e7c777', symbol = '') {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const context = canvas.getContext('2d');
  const gradient = context.createRadialGradient(48, 42, 4, 64, 64, 50);
  gradient.addColorStop(0, '#fff8df');
  gradient.addColorStop(.28, color);
  gradient.addColorStop(.72, color);
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  context.fillStyle = gradient;
  context.beginPath();
  context.arc(64, 64, 50, 0, TAU);
  context.fill();
  context.strokeStyle = 'rgba(255,245,214,.75)';
  context.lineWidth = 2;
  context.beginPath();
  context.arc(64, 64, 36, 0, TAU);
  context.stroke();
  context.fillStyle = '#071022';
  context.strokeStyle = '#071022';
  context.lineWidth = symbol === 'Chiron' ? 4 : 6;
  context.lineCap = 'round';
  context.lineJoin = 'round';
  if (symbol === 'Chiron') {
    context.beginPath();
    context.arc(59, 75, 9, 0, TAU);
    context.moveTo(59, 66);
    context.lineTo(59, 44);
    context.moveTo(59, 52);
    context.lineTo(70, 43);
    context.moveTo(59, 52);
    context.lineTo(70, 60);
    context.stroke();
  } else {
    context.font = '500 46px "DejaVu Sans", "Noto Sans Symbols 2", serif';
    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.fillText(symbol, 64, 67);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  return texture;
}

function makeRingTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 192;
  canvas.height = 192;
  const context = canvas.getContext('2d');
  context.strokeStyle = '#f2d892';
  context.lineWidth = 4;
  context.setLineDash([8, 8]);
  context.beginPath();
  context.arc(96, 96, 62, 0, TAU);
  context.stroke();
  context.setLineDash([]);
  context.fillStyle = '#f2d892';
  context.beginPath();
  context.arc(96, 22, 4, 0, TAU);
  context.fill();
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function disposeObject(object) {
  object.traverse((child) => {
    child.geometry?.dispose();
    if (Array.isArray(child.material)) child.material.forEach((material) => material.dispose());
    else child.material?.dispose();
    child.userData.disposableTexture?.dispose();
  });
}

function selectionKey(selection) {
  return selection ? `${selection.type}:${selection.id}` : '';
}

export class SkyDome {
  constructor(element, { onError, onSelect, onHover } = {}) {
    this.element = element;
    this.onError = onError;
    this.onSelect = onSelect;
    this.onHover = onHover;
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.visible = !document.hidden;
    this.dragging = false;
    this.pointerTravel = 0;
    this.previousPointer = null;
    this.targetRotation = { x: -.055, y: -.2 };
    this.layers = { planets: true, constellations: true, names: false, houses: true };
    this.density = 'high';
    this.view = 'dome';
    this.zoomByView = { dome: .86, disc: .9, inside: 1, natal: .9 };
    this.panByView = { disc: { x: 0, z: 0 }, natal: { x: 0, z: 0 } };
    this.natalAscendant = 0;
    this.selection = null;
    this.lastData = null;
    this.lastOptions = null;
    this.lastTime = performance.now();
    this.raycaster = new THREE.Raycaster();
    this.raycaster.params.Points.threshold = .12;
    this.raycaster.params.Line.threshold = .1;
    this.mouse = new THREE.Vector2();
    this.starTextures = [makeStarTexture(4, true), makeStarTexture(8, true), makeStarTexture(8, false)];
    this.planetTextures = {
      Sun: makePlanetTexture('#e3b458', '☉'), Moon: makePlanetTexture('#cbd3e6', '☽'),
      Mercury: makePlanetTexture('#b9a88c', '☿'), Venus: makePlanetTexture('#e5c17a', '♀'),
      Mars: makePlanetTexture('#b96e55', '♂'), Jupiter: makePlanetTexture('#d3aa78', '♃'),
      Saturn: makePlanetTexture('#cbb785', '♄'), Uranus: makePlanetTexture('#81bdc7', '♅'),
      Neptune: makePlanetTexture('#708bc7', '♆'),
      Pluto: makePlanetTexture('#9d87b8', '♇'),
      TrueNode: makePlanetTexture('#b79bcf', '☊'),
      Chiron: makePlanetTexture('#87a5c4', 'Chiron'),
    };
    this.ringTexture = makeRingTexture();

    try {
      this.setup();
      this.bindEvents();
      this.animate();
    } catch (error) {
      this.onError?.(error);
    }
  }

  setup() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(38, 1, .05, 100);
    this.camera.position.set(0, 3.15, 10.9);
    this.lookTarget = new THREE.Vector3(0, 1.7, 0);
    this.targetCameraPosition = this.camera.position.clone();
    this.targetCameraUp = new THREE.Vector3(0, 1, 0);
    this.targetLook = this.lookTarget.clone();
    this.camera.lookAt(this.lookTarget);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.element.appendChild(this.renderer.domElement);
    this.renderer.domElement.setAttribute('aria-hidden', 'true');

    this.root = new THREE.Group();
    this.root.rotation.x = this.targetRotation.x;
    this.root.rotation.y = this.targetRotation.y;
    this.scene.add(this.root);

    this.frameGroup = new THREE.Group();
    this.contentGroup = new THREE.Group();
    this.highlightGroup = new THREE.Group();
    this.root.add(this.frameGroup, this.contentGroup, this.highlightGroup);
    this.activePointers = new Map();
    this.pinchDistance = null;
    this.applyViewCamera();
    this.buildFrame();

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.element);
    this.resize();
  }

  buildFrame() {
    disposeObject(this.frameGroup);
    this.frameGroup.clear();
    const gridMaterial = rememberOpacity(new THREE.LineBasicMaterial({ color: 0x91a5d7, transparent: true, opacity: .27, depthWrite: false, linewidth: 1.5 }), .27);
    const rimMaterial = rememberOpacity(new THREE.LineBasicMaterial({ color: 0xd5b66d, transparent: true, opacity: .84, depthWrite: false, linewidth: 2 }), .84);

    if (this.view === 'natal') {
      const circles = [1.02, 2.22, 3.28, 3.68, RADIUS];
      circles.forEach((radius, index) => {
        const points = Array.from({ length: 129 }, (_, pointIndex) => {
          const angle = (pointIndex / 128) * TAU;
          return new THREE.Vector3(Math.sin(angle) * radius, 0, -Math.cos(angle) * radius);
        });
        this.frameGroup.add(makeLine(points, index === circles.length - 1 ? rimMaterial : gridMaterial));
      });
      for (let longitude = 0; longitude < 360; longitude += 30) {
        const inner = natalPosition({ eclipticLongitude: longitude }, 3.28, this.natalAscendant);
        const outer = natalPosition({ eclipticLongitude: longitude }, RADIUS, this.natalAscendant);
        this.frameGroup.add(makeLine([inner, outer], gridMaterial));
      }
      const minorTicks = [];
      const mediumTicks = [];
      const majorTicks = [];
      for (let longitude = 0; longitude < 360; longitude += 1) {
        const target = longitude % 10 === 0 ? majorTicks : longitude % 5 === 0 ? mediumTicks : minorTicks;
        const length = longitude % 10 === 0 ? .16 : longitude % 5 === 0 ? .105 : .055;
        target.push(
          natalPosition({ eclipticLongitude: longitude }, RADIUS - length, this.natalAscendant),
          natalPosition({ eclipticLongitude: longitude }, RADIUS, this.natalAscendant),
        );
      }
      const addTicks = (points, opacity) => {
        const material = rememberOpacity(new THREE.LineBasicMaterial({ color: 0xd8c58f, transparent: true, opacity, depthWrite: false }), opacity);
        this.frameGroup.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(points), material));
      };
      addTicks(minorTicks, .18);
      addTicks(mediumTicks, .34);
      addTicks(majorTicks, .58);
    } else if (this.view === 'disc') {
      [-60, -30, 0, 30, 60].forEach((latitude) => {
        const ringRadius = ((90 - latitude) / 180) * RADIUS;
        const points = Array.from({ length: 129 }, (_, index) => {
          const angle = (index / 128) * TAU;
          return new THREE.Vector3(Math.sin(angle) * ringRadius, 0, -Math.cos(angle) * ringRadius);
        });
        this.frameGroup.add(makeLine(points, latitude === 0 ? rimMaterial : gridMaterial));
      });
      const outer = Array.from({ length: 129 }, (_, index) => {
        const angle = (index / 128) * TAU;
        return new THREE.Vector3(Math.sin(angle) * RADIUS, 0, -Math.cos(angle) * RADIUS);
      });
      this.frameGroup.add(makeLine(outer, rimMaterial));
      for (let longitude = 0; longitude < 360; longitude += 30) {
        const angle = THREE.MathUtils.degToRad(longitude);
        this.frameGroup.add(makeLine([
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(Math.sin(angle) * RADIUS, 0, -Math.cos(angle) * RADIUS),
        ], gridMaterial));
      }
    } else {
      const shell = new THREE.Mesh(
        new THREE.SphereGeometry(RADIUS, 64, 40),
        rememberOpacity(new THREE.MeshBasicMaterial({ color: 0x4f5f91, transparent: true, opacity: .035, depthWrite: false, side: THREE.DoubleSide }), .035),
      );
      shell.renderOrder = -2;
      this.frameGroup.add(shell);
      this.depthMask = new THREE.Mesh(
        new THREE.SphereGeometry(RADIUS - .035, 64, 40),
        new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: true, side: THREE.FrontSide }),
      );
      this.depthMask.renderOrder = -1;
      this.depthMask.visible = this.view === 'dome';
      this.frameGroup.add(this.depthMask);

      for (let altitude = -75; altitude <= 75; altitude += 15) {
        const alt = THREE.MathUtils.degToRad(altitude);
        const ringRadius = Math.cos(alt) * RADIUS;
        const y = Math.sin(alt) * RADIUS;
        const points = Array.from({ length: 129 }, (_, index) => {
          const angle = (index / 128) * TAU;
          return new THREE.Vector3(Math.sin(angle) * ringRadius, y, -Math.cos(angle) * ringRadius);
        });
        this.frameGroup.add(makeLine(points, altitude === 0 ? rimMaterial : gridMaterial));
      }
      for (let azimuth = 0; azimuth < 360; azimuth += 30) {
        const points = [];
        for (let altitude = -90; altitude <= 90; altitude += 3) points.push(spherePosition({ altitude, azimuth }));
        this.frameGroup.add(makeLine(points, gridMaterial));
      }
    }

    this.coordinateGroup = new THREE.Group();
    this.frameGroup.add(this.coordinateGroup);
    this.updateCompass(this.compassLabels || { north: 'N', east: 'L', south: 'S', west: 'O', zenith: 'zênite', nadir: 'nadir' });
  }

  skyPosition(point, radius = RADIUS) {
    if (this.view === 'natal') return natalPosition(point, point.natalRadius || 2.78, this.natalAscendant);
    if (this.view !== 'disc') return spherePosition(point, radius);
    const position = discPosition(point, RADIUS);
    position.y = Math.max(.01, radius - RADIUS);
    return position;
  }

  addFrameLabel(text, point, scale = [.58, .25]) {
    const texture = makeTextTexture(text, { width: 220, height: 84, font: '700 27px "Space Mono"', color: '#b7c4e4' });
    const material = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: this.view === 'dome', opacity: .7 }), .7);
    const sprite = new THREE.Sprite(material);
    sprite.position.copy(point);
    sprite.scale.set(scale[0], scale[1], 1);
    sprite.userData.disposableTexture = texture;
    sprite.userData.frame = true;
    this.coordinateGroup.add(sprite);
  }

  addZodiacFrameIcon(index, point, scale = .46) {
    const texture = makeZodiacTexture(index);
    const material = rememberOpacity(new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: this.view === 'dome',
      opacity: .94,
    }), .94);
    const sprite = new THREE.Sprite(material);
    sprite.position.copy(point);
    sprite.scale.set(scale, scale, 1);
    sprite.renderOrder = 20;
    sprite.userData.disposableTexture = texture;
    sprite.userData.frame = true;
    this.coordinateGroup.add(sprite);
  }

  updateCompass(labels) {
    disposeObject(this.coordinateGroup);
    this.coordinateGroup.clear();
    if (this.view === 'natal') {
      Array.from({ length: 12 }, (_, index) => index).forEach((index) => {
        const point = natalPosition({ eclipticLongitude: index * 30 + 15 }, 4.08, this.natalAscendant);
        point.y = .13;
        this.addZodiacFrameIcon(index, point, .47);
      });
    } else if (this.view === 'disc') {
      Array.from({ length: 12 }, (_, index) => index).forEach((index) => {
        const point = discPosition({ eclipticLongitude: index * 30 + 15, eclipticLatitude: 0 }, RADIUS + .02);
        point.y = .13;
        this.addZodiacFrameIcon(index, point, .3);
      });
      for (let longitude = 0; longitude < 360; longitude += 30) {
        const point = discPosition({ eclipticLongitude: longitude, eclipticLatitude: -84 }, RADIUS);
        point.y = .12;
        this.addFrameLabel(`${longitude}°`, point, [.42, .2]);
      }
    } else {
      [[0, labels.north], [90, labels.east], [180, labels.south], [270, labels.west]].forEach(([azimuth, label]) => {
        this.addFrameLabel(label, new THREE.Vector3().copy(spherePosition({ altitude: 0, azimuth }, RADIUS + .2)).setY(-.05), [.48, .27]);
      });
      [30, 60, -30, -60].forEach((altitude) => {
        this.addFrameLabel(`${altitude}°`, spherePosition({ altitude, azimuth: 2 }, RADIUS + .06), [.44, .2]);
      });
      this.addFrameLabel(`${labels.zenith} · +90°`, new THREE.Vector3(0, RADIUS + .18, 0), [1.05, .24]);
      this.addFrameLabel(`${labels.nadir} · −90°`, new THREE.Vector3(0, -RADIUS - .18, 0), [1.05, .24]);
    }
    this.compassLabels = labels;
  }

  renderSky(data, options = {}) {
    this.lastData = data;
    this.lastOptions = options;
    this.selection = null;
    this.natalAscendant = data.natalChart?.ascendant || 0;
    this.onSelect?.(null);
    disposeObject(this.contentGroup);
    this.root.remove(this.contentGroup);
    this.contentGroup = new THREE.Group();
    this.root.add(this.contentGroup);

    this.starGroup = new THREE.Group();
    this.constellationGroup = new THREE.Group();
    this.constellationNameGroup = new THREE.Group();
    this.starNameGroup = new THREE.Group();
    this.planetGroup = new THREE.Group();
    this.houseGroup = new THREE.Group();
    this.aspectGroup = new THREE.Group();
    this.contentGroup.add(
      this.aspectGroup, this.houseGroup, this.starGroup, this.constellationGroup,
      this.constellationNameGroup, this.starNameGroup, this.planetGroup,
    );

    if (this.view === 'natal') {
      this.buildFrame();
      this.buildNatalHouses(data.natalChart);
      this.buildNatalAspects(data.natalChart);
      this.buildPlanets(data.natalChart?.planets || data.planets, options.bodyNames || {});
    } else {
      this.buildHouses(data.symbolicHouses);
      this.buildStars(data.stars);
      this.buildConstellations(data.constellations, data.labelById);
      this.buildConstellationNames(data.labels, options.language || 'pt');
      this.buildPlanets(data.planets, options.bodyNames || {});
    }
    this.applyLayers();
    this.clearHighlight();
  }

  buildStars(stars) {
    const limit = { low: 3.7, medium: 4.75, high: 6.05 }[this.density];
    const visible = stars
      .map((star) => ({ original: star, display: normalizedPoint(star) }))
      .filter(({ original, display }) => display && original.magnitude <= limit);
    const isHighlight = (star) => star.magnitude <= .65 || (star.name && star.magnitude <= 2.25);
    const ordinary = visible.filter(({ original }) => !isHighlight(original));
    const positions = new Float32Array(ordinary.length * 3);
    const sizes = new Float32Array(ordinary.length);
    const colors = new Float32Array(ordinary.length * 3);

    ordinary.forEach(({ original, display }, index) => {
      this.skyPosition(display, RADIUS + .018 + ((original.id % 7) * .002)).toArray(positions, index * 3);
      sizes[index] = THREE.MathUtils.clamp(2.4 - original.magnitude * .3, .5, 2.15);
      const temperature = Number.isFinite(original.bv) ? original.bv : .5;
      const color = temperature < .15 ? new THREE.Color(0xb7caff) : temperature > 1.1 ? new THREE.Color(0xe4c27e) : new THREE.Color(0xe8dfc7);
      color.toArray(colors, index * 3);
    });

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const material = rememberOpacity(new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      vertexColors: true,
      uniforms: { uOpacity: { value: .9 } },
      vertexShader: `
        attribute float aSize;
        varying vec3 vColor;
        void main() {
          vColor = color;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = aSize * clamp(10.0 / max(-mvPosition.z, 1.0), .68, 1.35);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        uniform float uOpacity;
        varying vec3 vColor;
        void main() {
          float d = distance(gl_PointCoord, vec2(.5));
          float alpha = smoothstep(.5, .1, d);
          gl_FragColor = vec4(vColor, alpha * uOpacity);
        }
      `,
    }), .9);
    const points = new THREE.Points(geometry, material);
    points.userData.items = ordinary.map(({ original, display }) => ({ ...original, display }));
    points.userData.selectionFamily = 'stars';
    this.starGroup.add(points);

    visible.filter(({ original }) => isHighlight(original)).forEach(({ original, display }, index) => {
      const textureIndex = original.magnitude <= .65 ? (original.bv < .15 ? 2 : 1) : 0;
      const materialSprite = rememberOpacity(new THREE.SpriteMaterial({
        map: this.starTextures[textureIndex],
        transparent: true, depthWrite: false, opacity: .88,
      }), .88);
      const sprite = new THREE.Sprite(materialSprite);
      sprite.position.copy(this.skyPosition(display, RADIUS + .05));
      const scale = THREE.MathUtils.clamp(.48 - original.magnitude * .11, .17, .58);
      sprite.scale.set(scale, scale, 1);
      sprite.userData.selection = { type: 'star', id: original.id, ...original, display };
      this.starGroup.add(sprite);
    });

    visible
      .filter(({ original }) => original.name && original.magnitude <= 2.25)
      .sort((a, b) => a.original.magnitude - b.original.magnitude)
      .slice(0, 18)
      .forEach(({ original, display }) => {
        const texture = makeTextTexture(original.name, { font: 'italic 29px "Fraunces", serif', color: '#c7d1eb', width: 380, height: 86 });
        const labelMaterial = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false, opacity: .66 }), .66);
        const label = new THREE.Sprite(labelMaterial);
        label.position.copy(this.skyPosition(display, RADIUS + .11));
        label.position.y += .12;
        label.scale.set(1.08, .245, 1);
        label.userData.disposableTexture = texture;
        label.userData.selection = { type: 'star', id: original.id, ...original, display };
        this.starNameGroup.add(label);
      });
  }

  buildConstellations(constellations, labelById) {
    constellations.forEach((runs, id) => {
      const label = labelById.get(id);
      runs.forEach((run) => {
        const visibleRuns = [];
        let active = [];
        run.forEach((point) => {
          const display = normalizedPoint(point);
          if (display) {
            const position = this.skyPosition(display, RADIUS + .07);
            if (this.view === 'disc' && active.length && active.at(-1).distanceTo(position) > RADIUS * .72) {
              if (active.length > 1) visibleRuns.push(active);
              active = [];
            }
            active.push(position);
          }
          else if (active.length > 1) {
            visibleRuns.push(active);
            active = [];
          } else active = [];
        });
        if (active.length > 1) visibleRuns.push(active);
        visibleRuns.forEach((points) => {
          const material = rememberOpacity(new THREE.LineDashedMaterial({
            color: 0xd9ba73, transparent: true, opacity: .43,
            dashSize: .03, gapSize: .045, depthWrite: false,
          }), .43);
          const line = makeLine(points, material);
          line.computeLineDistances();
          line.userData.selection = {
            type: 'constellation', id,
            name: label?.name || id,
            nameEn: label?.nameEn || label?.name || id,
          };
          this.constellationGroup.add(line);
        });
      });
    });
  }

  buildConstellationNames(labels, language) {
    labels.forEach((label) => {
      const display = normalizedPoint(label);
      if (!display) return;
      const name = language === 'en' ? label.nameEn : label.name;
      const texture = makeTextTexture(name, { font: 'italic 31px "Fraunces", serif', color: '#aebcdf', width: 400, height: 92 });
      const material = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false, opacity: label.rank <= 2 ? .72 : .48 }), label.rank <= 2 ? .72 : .48);
      const sprite = new THREE.Sprite(material);
      sprite.position.copy(this.skyPosition(display, RADIUS + .14));
      sprite.scale.set(1.35, .3, 1);
      sprite.userData.disposableTexture = texture;
      sprite.userData.rank = label.rank;
      sprite.userData.selection = { type: 'constellation', id: label.id, name: label.name, nameEn: label.nameEn };
      this.constellationNameGroup.add(sprite);
    });
  }

  buildPlanets(planets, bodyNames) {
    let previousLongitude = null;
    let lane = 0;
    [...planets].sort((a, b) => a.eclipticLongitude - b.eclipticLongitude).forEach((planet) => {
      const display = normalizedPoint(planet);
      if (!display) return;
      if (this.view === 'natal') {
        const gap = previousLongitude === null ? 360 : Math.abs(planet.eclipticLongitude - previousLongitude);
        lane = gap < 7 ? (lane + 1) % 3 : 0;
        display.natalRadius = 2.82 - lane * .28;
        previousLongitude = planet.eclipticLongitude;
      }
      const selection = { type: 'planet', id: planet.name, ...planet, display, label: bodyNames[planet.name] || planet.name };
      const material = rememberOpacity(new THREE.SpriteMaterial({
        map: this.planetTextures[planet.name], transparent: true, depthWrite: false, opacity: .98,
      }), .98);
      const sprite = new THREE.Sprite(material);
      sprite.position.copy(this.skyPosition(display, RADIUS + .17));
      const size = ['disc', 'natal'].includes(this.view) ? (planet.name === 'Sun' || planet.name === 'Moon' ? .48 : .38) : (planet.name === 'Sun' || planet.name === 'Moon' ? .42 : .28);
      sprite.scale.set(size, size, 1);
      sprite.userData.selection = selection;
      this.planetGroup.add(sprite);
    });
  }

  buildNatalHouses(natalChart) {
    if (!natalChart?.cusps?.length) return;
    natalChart.cusps.forEach((longitude, index) => {
      const color = index % 3 === 0 ? 0xd6b66f : 0x9177ca;
      const material = rememberOpacity(new THREE.LineBasicMaterial({
        color,
        transparent: true,
        opacity: index % 3 === 0 ? .92 : .64,
        depthWrite: false,
        linewidth: index % 3 === 0 ? 2 : 1.5,
      }), index % 3 === 0 ? .92 : .64);
      const guidePoints = [
        natalPosition({ eclipticLongitude: longitude }, 1.02, this.natalAscendant).setY(.04),
        natalPosition({ eclipticLongitude: longitude }, 3.28, this.natalAscendant).setY(.04),
      ];
      this.houseGroup.add(makeLine(guidePoints, material));
      const structuralGuide = makeStructureTube(
        guidePoints,
        color,
        index % 3 === 0 ? .008 : .005,
        index % 3 === 0 ? .34 : .2,
      );
      if (structuralGuide) this.houseGroup.add(structuralGuide);

      const next = natalChart.cusps[(index + 1) % 12];
      const span = ((next - longitude) % 360 + 360) % 360;
      const center = longitude + span / 2;
      const texture = makeTextTexture(ROMAN[index], { font: '500 31px "Fraunces", serif', color: '#bca4e2', width: 150, height: 72 });
      const labelMaterial = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false, opacity: .82 }), .82);
      const label = new THREE.Sprite(labelMaterial);
      label.position.copy(natalPosition({ eclipticLongitude: center }, 1.55, this.natalAscendant));
      label.position.y = .13;
      label.scale.set(.42, .2, 1);
      label.userData.disposableTexture = texture;
      this.houseGroup.add(label);
    });

    [
      ['ASC', natalChart.ascendant, 0xdab867],
      ['MC', natalChart.midheaven, 0xb9c8eb],
      ['DSC', natalChart.ascendant + 180, 0xdab867],
      ['IC', natalChart.midheaven + 180, 0xb9c8eb],
    ].forEach(([text, longitude, color]) => {
      const texture = makeTextTexture(text, { font: '700 28px "Space Mono", monospace', color: `#${color.toString(16).padStart(6, '0')}`, width: 180, height: 72 });
      const material = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false, opacity: .9 }), .9);
      const label = new THREE.Sprite(material);
      label.position.copy(natalPosition({ eclipticLongitude: longitude }, 4.92, this.natalAscendant));
      label.position.y = .16;
      label.scale.set(.55, .22, 1);
      label.userData.disposableTexture = texture;
      this.houseGroup.add(label);
    });
  }

  buildNatalAspects(natalChart) {
    if (!natalChart?.aspects?.length) return;
    const byName = new Map(natalChart.planets.map((planet) => [planet.name, planet]));
    natalChart.aspects.slice(0, 34).forEach((aspect) => {
      const from = byName.get(aspect.from);
      const to = byName.get(aspect.to);
      if (!from || !to) return;
      const color = aspect.family === 'tense' ? 0xd4776e
        : aspect.family === 'harmonic' ? 0x6e91d6
          : aspect.family === 'neutral' ? 0xd7b56a : 0x927fb7;
      const opacity = .24 + aspect.strength * .42;
      const material = aspect.family === 'minor'
        ? new THREE.LineDashedMaterial({ color, transparent: true, opacity, dashSize: .05, gapSize: .06, depthWrite: false })
        : new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false });
      rememberOpacity(material, opacity);
      const line = makeLine([
        natalPosition(from, .98, this.natalAscendant).setY(.03),
        natalPosition(to, .98, this.natalAscendant).setY(.03),
      ], material);
      line.userData.selection = {
        ...aspect,
        type: 'aspect',
        id: `${aspect.from}-${aspect.type}-${aspect.to}`,
        aspectType: aspect.type,
        fromDisplay: from,
        toDisplay: to,
      };
      if (line.computeLineDistances) line.computeLineDistances();
      this.aspectGroup.add(line);
    });
  }

  buildHouses(symbolicHouses) {
    if (!symbolicHouses) return;
    const eclipticPoints = [];
    let active = [];
    symbolicHouses.ecliptic.forEach((point) => {
      const display = normalizedPoint(point);
      if (display) active.push(this.skyPosition(display, RADIUS + .085));
      else if (active.length > 1) {
        eclipticPoints.push(active);
        active = [];
      } else active = [];
    });
    if (active.length > 1) eclipticPoints.push(active);
    eclipticPoints.forEach((points) => {
      const material = rememberOpacity(new THREE.LineBasicMaterial({ color: 0x8d72ca, transparent: true, opacity: .65, depthWrite: false }), .65);
      this.houseGroup.add(makeLine(points, material));
    });

    symbolicHouses.houses.forEach((house, houseIndex) => {
      if (this.view === 'disc') {
        const angle = THREE.MathUtils.degToRad(house.start.eclipticLongitude);
        const boundaryMaterial = rememberOpacity(new THREE.LineBasicMaterial({ color: 0xc7a65f, transparent: true, opacity: .48, depthWrite: false }), .48);
        const boundary = makeLine([
          new THREE.Vector3(0, .035, 0),
          new THREE.Vector3(Math.sin(angle) * RADIUS, .035, -Math.cos(angle) * RADIUS),
        ], boundaryMaterial);
        this.houseGroup.add(boundary);
      }
      const positions = [];
      for (let index = 0; index < house.ribbon.length - 1; index += 1) {
        const current = house.ribbon[index];
        const next = house.ribbon[index + 1];
        const a = normalizedPoint(current.inner);
        const b = normalizedPoint(current.outer);
        const c = normalizedPoint(next.outer);
        const d = normalizedPoint(next.inner);
        if (!a || !b || !c || !d) continue;
        const pa = this.skyPosition(a, RADIUS + .045);
        const pb = this.skyPosition(b, RADIUS + .045);
        const pc = this.skyPosition(c, RADIUS + .045);
        const pd = this.skyPosition(d, RADIUS + .045);
        [pa, pb, pc, pa, pc, pd].forEach((point) => positions.push(point.x, point.y, point.z));
      }
      if (positions.length) {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        const opacity = this.view === 'disc' ? (houseIndex % 2 === 0 ? .13 : .065) : (houseIndex % 2 === 0 ? .052 : .024);
        const material = rememberOpacity(new THREE.MeshBasicMaterial({
          color: houseIndex % 2 === 0 ? 0x8f72ca : 0xd2ad65,
          transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide,
        }), opacity);
        this.houseGroup.add(new THREE.Mesh(geometry, material));
      }
      const center = normalizedPoint(house.center);
      if (center) {
        const texture = makeTextTexture(ROMAN[houseIndex], { font: '400 28px "Fraunces", serif', color: '#a98dd9', width: 160, height: 72 });
        const material = rememberOpacity(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false, opacity: .78 }), .78);
        const sprite = new THREE.Sprite(material);
        if (this.view === 'disc') {
          sprite.position.copy(discPosition({ ...center, eclipticLatitude: -22 }, RADIUS));
          sprite.position.y = .15;
        } else sprite.position.copy(this.skyPosition(center, RADIUS + .12));
        sprite.scale.set(.4, .2, 1);
        sprite.userData.disposableTexture = texture;
        this.houseGroup.add(sprite);
      }
    });
  }

  setLayers(layers, density) {
    const densityChanged = density && density !== this.density;
    this.layers = { ...this.layers, ...layers };
    if (density) this.density = density;
    this.applyLayers();
    if (densityChanged && this.lastData) this.renderSky(this.lastData, this.lastOptions);
  }

  applyLayers() {
    const natal = this.view === 'natal';
    if (this.starGroup) this.starGroup.visible = !natal;
    if (this.constellationNameGroup) {
      this.constellationNameGroup.children.forEach((label) => {
        label.visible = label.userData.rank <= 2 || this.layers.names;
      });
    }
    if (this.constellationGroup) this.constellationGroup.visible = !natal && this.layers.constellations;
    if (this.constellationNameGroup) this.constellationNameGroup.visible = !natal && this.layers.constellations;
    if (this.starNameGroup) this.starNameGroup.visible = !natal && this.layers.names;
    if (this.planetGroup) this.planetGroup.visible = natal || this.layers.planets;
    if (this.houseGroup) this.houseGroup.visible = natal || this.layers.houses;
    if (this.aspectGroup) this.aspectGroup.visible = natal;
  }

  setView(view) {
    if (!['dome', 'disc', 'inside', 'natal'].includes(view)) return;
    this.view = view;
    this.setSelection(null);
    if (view === 'disc' || view === 'natal') {
      this.targetCameraUp.set(0, 0, -1);
      this.targetRotation.x = 0;
      this.targetRotation.y = 0;
    } else if (view === 'inside') {
      this.targetCameraUp.set(0, 1, 0);
      this.targetRotation.x = 0;
    } else {
      this.targetCameraUp.set(0, 1, 0);
      this.targetRotation.x = -.055;
    }
    this.applyViewCamera();
    this.buildFrame();
    if (this.lastData) this.renderSky(this.lastData, this.lastOptions);
    this.camera.updateProjectionMatrix();
    if (this.reducedMotion) {
      this.camera.position.copy(this.targetCameraPosition);
      this.camera.up.copy(this.targetCameraUp);
      this.lookTarget.copy(this.targetLook);
    }
  }

  applyViewCamera() {
    const zoom = this.zoomByView[this.view];
    if (this.view === 'disc' || this.view === 'natal') {
      const pan = this.panByView[this.view];
      this.targetCameraPosition.set(pan.x, 13.8 / zoom, pan.z + .01);
      this.targetLook.set(pan.x, 0, pan.z);
      this.camera.fov = 44;
    } else if (this.view === 'inside') {
      this.targetCameraPosition.set(0, 0, 0);
      this.targetLook.set(0, 0, -2.4);
      this.camera.fov = THREE.MathUtils.clamp(78 / zoom, 34, 92);
    } else {
      this.targetCameraPosition.set(0, 1.7 / zoom, 13.2 / zoom);
      this.targetLook.set(0, 0, 0);
      this.camera.fov = 39;
    }
    this.camera.updateProjectionMatrix();
  }

  zoomBy(factor) {
    const planar = this.view === 'disc' || this.view === 'natal';
    this.zoomByView[this.view] = THREE.MathUtils.clamp(this.zoomByView[this.view] * factor, planar ? .35 : .68, planar ? 8 : 2.25);
    this.applyViewCamera();
  }

  getSearchItems(language = 'pt') {
    if (!this.lastData) return [];
    const planetSource = this.view === 'natal' && this.lastData.natalChart?.planets
      ? this.lastData.natalChart.planets : this.lastData.planets;
    const planets = planetSource.map((planet) => ({
      type: 'planet', id: planet.name, ...planet, display: planet,
      label: this.lastOptions?.bodyNames?.[planet.name] || planet.name,
    }));
    const constellations = this.lastData.labels.map((label) => ({
      type: 'constellation', id: label.id, ...label, display: label,
      label: language === 'en' ? label.nameEn : label.name,
    }));
    const stars = this.lastData.stars
      .filter((star) => star.name && star.magnitude <= 2.25)
      .map((star) => ({ type: 'star', id: star.id, ...star, display: star, label: star.name }));
    return [...planets, ...constellations, ...stars].sort((a, b) => a.label.localeCompare(b.label, language));
  }

  focusSelection(selection) {
    if (!selection?.display) return;
    this.setSelection(selection);
    if (this.view === 'disc' || this.view === 'natal') {
      const point = this.skyPosition(selection.display);
      this.panByView[this.view] = { x: point.x, z: point.z };
      this.zoomByView[this.view] = Math.max(this.zoomByView[this.view], 1.45);
      this.applyViewCamera();
      return;
    }
    const azimuth = selection.display.azimuth || 0;
    const altitude = selection.display.altitude || 0;
    if (this.view === 'inside') {
      this.targetRotation.y = THREE.MathUtils.degToRad(-azimuth);
      this.targetRotation.x = THREE.MathUtils.degToRad(-altitude);
    } else {
      this.targetRotation.y = THREE.MathUtils.degToRad(180 - azimuth);
      this.targetRotation.x = THREE.MathUtils.degToRad(altitude);
    }
  }

  focusAspect(selection) {
    if (!selection?.fromDisplay || !selection?.toDisplay) return;
    this.setSelection(selection);
  }

  highlightConstellation(selection) {
    this.constellationGroup.traverse((object) => {
      if (object.userData.selection?.id !== selection.id || !object.isLine) return;
      const points = geometryPoints(object);
      if (points.length < 2) return;
      const solid = makeLine(points, new THREE.LineBasicMaterial({
        color: 0xf0cf75,
        transparent: true,
        opacity: 1,
        depthWrite: false,
      }));
      solid.renderOrder = 12;
      this.highlightGroup.add(solid);
      const glow = makeGlowTube(points, 0xe5b955, .022, .2);
      if (glow) {
        glow.renderOrder = 11;
        this.highlightGroup.add(glow);
      }
    });

    const vertices = this.lastData?.constellations?.get(selection.id)?.flat() || [];
    const catalogStars = this.lastData?.stars || [];
    const vertexStars = new Map();
    vertices.forEach((vertex) => {
      let nearestStar = null;
      let nearestDistance = Infinity;
      catalogStars.forEach((star) => {
        const distance = angularDistanceDegrees(vertex, star);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestStar = star;
        }
      });
      // The line catalogue and star catalogue share the same J2000 vertices.
      // A tight tolerance avoids illuminating unrelated stars along each segment.
      if (nearestStar && nearestDistance <= .05) vertexStars.set(nearestStar.id, nearestStar);
    });
    const stars = [...vertexStars.values()];
    stars.forEach((star) => {
      const textureIndex = star.magnitude <= 1 ? (star.bv < .15 ? 2 : 1) : 0;
      const material = new THREE.SpriteMaterial({
        map: this.starTextures[textureIndex],
        transparent: true,
        opacity: .98,
        depthWrite: false,
      });
      const sprite = new THREE.Sprite(material);
      sprite.position.copy(this.skyPosition(star, RADIUS + .12));
      const scale = star.magnitude <= 1 ? .27 : .15;
      sprite.scale.set(scale, scale, 1);
      sprite.renderOrder = 13;
      this.highlightGroup.add(sprite);
    });
  }

  highlightAspect(selection) {
    const from = natalPosition(selection.fromDisplay, .98, this.natalAscendant).setY(.035);
    const to = natalPosition(selection.toDisplay, .98, this.natalAscendant).setY(.035);
    const color = selection.family === 'tense' ? 0xff8c79
      : selection.family === 'harmonic' ? 0x83a8ff
        : selection.family === 'neutral' ? 0xf1d174 : 0xb9a0eb;
    const line = makeLine([from, to], new THREE.LineBasicMaterial({
      color,
      transparent: true,
      opacity: 1,
      depthWrite: false,
    }));
    line.renderOrder = 13;
    this.highlightGroup.add(line);
    const glow = makeGlowTube([from, to], color, .026, .26);
    if (glow) {
      glow.renderOrder = 12;
      this.highlightGroup.add(glow);
    }
  }

  setSelection(selection) {
    this.selection = selection;
    this.clearHighlight();
    const selectedKey = selectionKey(selection);
    this.contentGroup.traverse((object) => {
      const materials = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
      materials.forEach((material) => {
        const base = material.userData.baseOpacity ?? material.opacity ?? 1;
        const objectKey = selectionKey(object.userData.selection);
        const isMatch = selectedKey && objectKey === selectedKey;
        const familyMatch = selection?.type === 'star' && object.userData.selectionFamily === 'stars';
        const nextOpacity = !selection ? base : isMatch ? Math.min(1, base * 1.55) : familyMatch ? base * .16 : base * .2;
        if (material.uniforms?.uOpacity) material.uniforms.uOpacity.value = nextOpacity;
        else material.opacity = nextOpacity;
      });
    });
    if (selection?.display) {
      const material = new THREE.SpriteMaterial({ map: this.ringTexture, transparent: true, depthTest: false, opacity: .92 });
      const marker = new THREE.Sprite(material);
      marker.position.copy(this.skyPosition(selection.display, RADIUS + .22));
      marker.scale.set(.62, .62, 1);
      this.highlightGroup.add(marker);
    }
    if (selection?.type === 'constellation') this.highlightConstellation(selection);
    if (selection?.type === 'aspect') this.highlightAspect(selection);
    this.onSelect?.(selection);
  }

  clearHighlight() {
    disposeObject(this.highlightGroup);
    this.highlightGroup.clear();
  }

  pick(event, notifyHover = false) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersections = this.raycaster.intersectObjects([
      this.planetGroup, this.starNameGroup, this.constellationNameGroup,
      this.constellationGroup, this.starGroup, this.aspectGroup,
    ].filter(Boolean), true);
    let selection = null;
    for (const intersection of intersections) {
      const object = intersection.object;
      if (!object.visible) continue;
      if (object.isPoints) continue;
      if (object.userData.selection) selection = object.userData.selection;
      if (selection) break;
    }
    if (notifyHover) {
      this.renderer.domElement.style.cursor = selection ? 'pointer' : this.dragging ? 'grabbing' : 'grab';
      this.onHover?.(selection, event);
    }
    return selection;
  }

  bindEvents() {
    const canvas = this.renderer.domElement;
    canvas.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      this.activePointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      this.dragging = true;
      this.pointerTravel = 0;
      this.previousPointer = { x: event.clientX, y: event.clientY };
      canvas.setPointerCapture(event.pointerId);
      this.element.classList.add('is-dragging');
      this.onHover?.(null, event);
      if (this.activePointers.size === 2) {
        const [a, b] = [...this.activePointers.values()];
        this.pinchDistance = Math.hypot(a.x - b.x, a.y - b.y);
        this.pointerTravel = 100;
      }
    });
    canvas.addEventListener('pointermove', (event) => {
      if (this.activePointers.has(event.pointerId)) this.activePointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (this.activePointers.size === 2) {
        event.preventDefault();
        const [a, b] = [...this.activePointers.values()];
        const distance = Math.hypot(a.x - b.x, a.y - b.y);
        if (this.pinchDistance && distance > 0) this.zoomBy(distance / this.pinchDistance);
        this.pinchDistance = distance;
        return;
      }
      if (!this.dragging || !this.previousPointer) {
        this.pick(event, true);
        return;
      }
      const dx = event.clientX - this.previousPointer.x;
      const dy = event.clientY - this.previousPointer.y;
      this.pointerTravel += Math.abs(dx) + Math.abs(dy);
      if (this.view === 'disc' || this.view === 'natal') {
        const pan = this.panByView[this.view];
        const scale = .012 / this.zoomByView[this.view];
        pan.x -= dx * scale;
        pan.z -= dy * scale;
        this.applyViewCamera();
      } else {
        const horizontalDirection = this.view === 'inside' ? -1 : 1;
        this.targetRotation.y += dx * (this.view === 'inside' ? .0028 : .004) * horizontalDirection;
        const limits = this.view === 'inside' ? [-1.35, 1.35] : [-1.2, 1.2];
        const verticalDirection = this.view === 'inside' ? -1 : 1;
        this.targetRotation.x = THREE.MathUtils.clamp(
          this.targetRotation.x + dy * .0025 * verticalDirection,
          limits[0],
          limits[1],
        );
      }
      this.previousPointer = { x: event.clientX, y: event.clientY };
    });
    const endDrag = (event) => {
      const wasPinching = this.activePointers.size > 1 || this.pinchDistance !== null;
      this.activePointers.delete(event.pointerId);
      if (wasPinching) {
        this.pointerTravel = 100;
        this.pinchDistance = null;
      }
      if (this.activePointers.size === 1) {
        this.previousPointer = [...this.activePointers.values()][0];
        return;
      }
      if (this.dragging && this.pointerTravel < 7 && !wasPinching) {
        const selection = this.pick(event);
        this.setSelection(selection);
      }
      this.dragging = false;
      this.previousPointer = null;
      this.element.classList.remove('is-dragging');
      canvas.style.cursor = 'grab';
    };
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);
    canvas.addEventListener('lostpointercapture', () => {
      if (!this.activePointers.size) {
        this.dragging = false;
        this.previousPointer = null;
        this.element.classList.remove('is-dragging');
      }
    });
    canvas.addEventListener('pointerleave', (event) => this.onHover?.(null, event));
    canvas.addEventListener('wheel', (event) => {
      event.preventDefault();
      this.zoomBy(Math.exp(-event.deltaY * .00125));
    }, { passive: false });

    this.visibilityHandler = () => { this.visible = !document.hidden; };
    document.addEventListener('visibilitychange', this.visibilityHandler);
  }

  resize() {
    if (!this.renderer) return;
    const width = Math.max(1, this.element.clientWidth);
    const height = Math.max(1, this.element.clientHeight);
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  animate(now = performance.now()) {
    this.raf = requestAnimationFrame((time) => this.animate(time));
    if (!this.visible || !this.renderer) return;
    const delta = Math.min((now - this.lastTime) / 1000, .05);
    this.lastTime = now;
    if (!this.dragging && !this.selection && !this.reducedMotion && this.view === 'dome') this.targetRotation.y += delta * .006;
    this.root.rotation.x += (this.targetRotation.x - this.root.rotation.x) * .065;
    this.root.rotation.y += (this.targetRotation.y - this.root.rotation.y) * .065;
    this.camera.position.lerp(this.targetCameraPosition, .075);
    this.camera.up.lerp(this.targetCameraUp, .075).normalize();
    this.lookTarget.lerp(this.targetLook, .075);
    this.camera.lookAt(this.lookTarget);
    this.renderer.render(this.scene, this.camera);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.resizeObserver?.disconnect();
    document.removeEventListener('visibilitychange', this.visibilityHandler);
    disposeObject(this.root);
    this.starTextures.forEach((texture) => texture.dispose());
    Object.values(this.planetTextures).forEach((texture) => texture.dispose());
    this.ringTexture.dispose();
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }
}
