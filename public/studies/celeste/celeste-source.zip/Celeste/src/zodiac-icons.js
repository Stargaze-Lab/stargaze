const PATHS = [
  '<path d="M32 55V31C32 18 26 10 18 10C11 10 8 15 9 21C10 26 13 29 17 31M32 31C32 18 38 10 46 10C53 10 56 15 55 21C54 26 51 29 47 31"/>',
  '<circle cx="32" cy="39" r="14"/><path d="M17 9C22 9 24 11 27 16C29 20 30 23 32 25C34 23 35 20 37 16C40 11 42 9 47 9"/>',
  '<path d="M15 10C25 15 39 15 49 10M15 54C25 49 39 49 49 54M23 13V51M41 13V51"/>',
  '<path d="M13 22C22 14 40 14 51 22M51 42C41 50 23 50 13 42"/><circle cx="17" cy="27" r="7"/><circle cx="47" cy="37" r="7"/>',
  '<circle cx="18" cy="38" r="8"/><path d="M26 38C31 34 30 23 35 15C40 7 50 8 52 16C55 26 45 32 42 40C39 48 42 55 48 55C52 55 55 52 56 48"/>',
  '<path d="M9 50V23C9 14 20 14 20 23V50M20 23C20 14 31 14 31 23V50M31 23C31 14 42 14 42 23V39C42 48 49 53 55 48M42 39C49 37 54 40 53 46C52 52 46 56 37 59"/>',
  '<path d="M8 49H56M14 40H50M20 36C20 25 25 20 32 20C39 20 44 25 44 36"/>',
  '<path d="M9 50V23C9 14 20 14 20 23V50M20 23C20 14 31 14 31 23V50M31 23C31 14 42 14 42 23V42C42 49 49 51 56 47M49 43L56 47L50 53"/>',
  '<path d="M12 52L52 12M34 12H52V30M14 30L34 50M14 50L34 30"/>',
  '<path d="M9 20C12 13 20 12 24 18C26 21 26 27 26 34V45M26 22C29 13 39 13 41 21C43 29 39 42 31 55M40 39C44 34 51 35 54 40C57 45 54 51 49 53C43 55 37 50 40 39"/>',
  '<path d="M7 23L16 14L25 23L34 14L43 23L52 14M7 45L16 36L25 45L34 36L43 45L52 36"/>',
  '<path d="M18 10C30 18 30 46 18 54M46 10C34 18 34 46 46 54M10 32H54"/>',
];

export const ZODIAC_DATA = [
  { id: 'aries', element: 'fire', modality: 'cardinal' },
  { id: 'taurus', element: 'earth', modality: 'fixed' },
  { id: 'gemini', element: 'air', modality: 'mutable' },
  { id: 'cancer', element: 'water', modality: 'cardinal' },
  { id: 'leo', element: 'fire', modality: 'fixed' },
  { id: 'virgo', element: 'earth', modality: 'mutable' },
  { id: 'libra', element: 'air', modality: 'cardinal' },
  { id: 'scorpio', element: 'water', modality: 'fixed' },
  { id: 'sagittarius', element: 'fire', modality: 'mutable' },
  { id: 'capricorn', element: 'earth', modality: 'cardinal' },
  { id: 'aquarius', element: 'air', modality: 'fixed' },
  { id: 'pisces', element: 'water', modality: 'mutable' },
];

export function zodiacSvg(index, { className = 'zodiac-icon', color = 'currentColor' } = {}) {
  const safeIndex = ((index % 12) + 12) % 12;
  return `<svg xmlns="http://www.w3.org/2000/svg" class="${className}" viewBox="0 0 64 64" aria-hidden="true" fill="none" stroke="${color}" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round">${PATHS[safeIndex]}</svg>`;
}

export function drawZodiacGlyph(context, index, {
  color = '#e7cf91', size = 128, padding = 12,
} = {}) {
  const safeIndex = ((index % 12) + 12) % 12;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.innerHTML = PATHS[safeIndex];
  const scale = (size - padding * 2) / 64;
  context.save();
  context.translate(padding, padding);
  context.scale(scale, scale);
  context.strokeStyle = color;
  context.lineWidth = 3.6;
  context.lineCap = 'round';
  context.lineJoin = 'round';
  svg.querySelectorAll('path').forEach((node) => context.stroke(new Path2D(node.getAttribute('d'))));
  svg.querySelectorAll('circle').forEach((node) => {
    context.beginPath();
    context.arc(
      Number(node.getAttribute('cx')),
      Number(node.getAttribute('cy')),
      Number(node.getAttribute('r')),
      0,
      Math.PI * 2,
    );
    context.stroke();
  });
  context.restore();
}
