import SwissEph from 'swisseph-wasm';

const BODY_DEFINITIONS = [
  ['Sun', 'SE_SUN', '☉'],
  ['Moon', 'SE_MOON', '☽'],
  ['Mercury', 'SE_MERCURY', '☿'],
  ['Venus', 'SE_VENUS', '♀'],
  ['Mars', 'SE_MARS', '♂'],
  ['Jupiter', 'SE_JUPITER', '♃'],
  ['Saturn', 'SE_SATURN', '♄'],
  ['Uranus', 'SE_URANUS', '♅'],
  ['Neptune', 'SE_NEPTUNE', '♆'],
  ['Pluto', 'SE_PLUTO', '♇'],
  ['TrueNode', 'SE_TRUE_NODE', '☊'],
  ['Chiron', 'SE_CHIRON', '⚷'],
];

const OBSERVED_BODY_NAMES = new Set([
  'Sun', 'Moon', 'Mercury', 'Venus', 'Mars',
  'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto',
]);

const ASPECTS = [
  { type: 'conjunction', symbol: '☌', angle: 0, orb: 8, family: 'neutral' },
  { type: 'opposition', symbol: '☍', angle: 180, orb: 8, family: 'tense' },
  { type: 'trine', symbol: '△', angle: 120, orb: 6, family: 'harmonic' },
  { type: 'square', symbol: '□', angle: 90, orb: 6, family: 'tense' },
  { type: 'sextile', symbol: '⚹', angle: 60, orb: 4, family: 'harmonic' },
  { type: 'quincunx', symbol: '⚻', angle: 150, orb: 3, family: 'minor' },
];

let swiss;
let initialization;

function mod360(value) {
  return ((value % 360) + 360) % 360;
}

function houseForLongitude(longitude, cusps) {
  const value = mod360(longitude);
  for (let index = 0; index < 12; index += 1) {
    const start = cusps[index];
    const end = cusps[(index + 1) % 12];
    const span = mod360(end - start);
    if (mod360(value - start) < span) return index + 1;
  }
  return 1;
}

function calculateAspects(planets) {
  const aspects = [];
  for (let first = 0; first < planets.length; first += 1) {
    for (let second = first + 1; second < planets.length; second += 1) {
      const a = planets[first];
      const b = planets[second];
      const separation = Math.abs(mod360(a.eclipticLongitude - b.eclipticLongitude));
      const angle = separation > 180 ? 360 - separation : separation;
      for (const definition of ASPECTS) {
        const delta = Math.abs(angle - definition.angle);
        if (delta <= definition.orb) {
          aspects.push({
            ...definition,
            from: a.name,
            to: b.name,
            angle,
            exactness: delta,
            strength: 1 - delta / definition.orb,
          });
          break;
        }
      }
    }
  }
  return aspects.sort((a, b) => b.strength - a.strength);
}

function horizontalPoint(swe, julianDay, geoposition, longitude, latitude = 0, distance = 1) {
  const horizontal = swe.azalt(
    julianDay,
    swe.SE_ECL2HOR,
    geoposition,
    0,
    10,
    [mod360(longitude), latitude, distance],
  );
  return {
    eclipticLongitude: mod360(longitude),
    eclipticLatitude: latitude,
    altitude: horizontal.trueAltitude,
    // Swiss Ephemeris measures azimuth from south towards west. Celeste uses
    // the navigation convention: north 0°, east 90°.
    azimuth: mod360(horizontal.azimuth + 180),
  };
}

function buildObservedHouses(swe, julianDay, geoposition, cusps) {
  const project = (longitude, latitude = 0) => ({
    longitude: mod360(longitude),
    ...horizontalPoint(swe, julianDay, geoposition, longitude, latitude),
  });
  const ecliptic = [];
  for (let longitude = 0; longitude <= 360; longitude += 2) ecliptic.push(project(longitude));

  const houses = cusps.map((start, index) => {
    const end = cusps[(index + 1) % 12];
    const span = mod360(end - start);
    const ribbon = [];
    for (let step = 0; step <= 15; step += 1) {
      const longitude = start + (span * step) / 15;
      ribbon.push({ inner: project(longitude, -4.2), outer: project(longitude, 4.2) });
    }
    return {
      index: index + 1,
      start: project(start),
      center: project(start + span / 2),
      end: project(start + span),
      ribbon,
    };
  });
  return { ascendant: cusps[0], ecliptic, houses };
}

export async function initializeSwissEphemeris() {
  if (swiss) return swiss;
  if (!initialization) {
    initialization = (async () => {
      const instance = new SwissEph();
      await instance.initSwissEph();
      swiss = instance;
      return swiss;
    })();
  }
  return initialization;
}

export async function calculateSwissChart({ date, latitude, longitude, elevation = 0 }) {
  const swe = await initializeSwissEphemeris();
  const utcHour = date.getUTCHours()
    + date.getUTCMinutes() / 60
    + date.getUTCSeconds() / 3600;
  const julianDay = swe.julday(
    date.getUTCFullYear(),
    date.getUTCMonth() + 1,
    date.getUTCDate(),
    utcHour,
  );
  const flags = swe.SEFLG_SWIEPH | swe.SEFLG_SPEED;
  const geoposition = [longitude, latitude, elevation];
  const houseResult = swe.houses(julianDay, latitude, longitude, 'P');
  const cusps = Array.from(houseResult.cusps).slice(1, 13).map(mod360);

  const planets = BODY_DEFINITIONS.map(([name, constant, symbol]) => {
    const position = swe.calc_ut(julianDay, swe[constant], flags);
    const eclipticLongitude = mod360(position[0]);
    return {
      name,
      symbol,
      eclipticLongitude,
      eclipticLatitude: position[1],
      distance: position[2],
      longitudeSpeed: position[3],
      retrograde: position[3] < 0,
      signIndex: Math.floor(eclipticLongitude / 30),
      degreeInSign: eclipticLongitude % 30,
      house: houseForLongitude(eclipticLongitude, cusps),
    };
  });

  swe.set_topo(longitude, latitude, elevation);
  const observedPlanets = BODY_DEFINITIONS
    .filter(([name]) => OBSERVED_BODY_NAMES.has(name))
    .map(([name, constant, symbol]) => {
      const position = swe.calc_ut(julianDay, swe[constant], flags | swe.SEFLG_TOPOCTR);
      return {
        name,
        symbol,
        distance: position[2],
        longitudeSpeed: position[3],
        retrograde: position[3] < 0,
        ...horizontalPoint(swe, julianDay, geoposition, position[0], position[1], position[2]),
      };
    });

  return {
    engine: 'Swiss Ephemeris',
    version: swe.version(),
    system: 'placidus',
    zodiac: 'tropical',
    referenceFrame: 'geocentric',
    julianDay,
    ascendant: mod360(houseResult.ascmc[0]),
    midheaven: mod360(houseResult.ascmc[1]),
    armc: mod360(houseResult.ascmc[2]),
    vertex: mod360(houseResult.ascmc[3]),
    cusps,
    planets,
    observedPlanets,
    observedHouses: buildObservedHouses(swe, julianDay, geoposition, cusps),
    aspects: calculateAspects(planets),
  };
}

export const calculateSwissNatal = calculateSwissChart;
