# Celeste — créditos e licenças

Copyright © 2026 Stargaze contributors.

Celeste é software livre distribuído sob a **GNU Affero General Public License v3.0 ou posterior**. Veja `LICENSE`.

## Swiss Ephemeris

O mapa natal usa o Swiss Ephemeris, criado por Dieter Koch e Alois Treindl e publicado pela Astrodienst AG. O Swiss Ephemeris possui licenciamento duplo; Celeste adota a opção AGPL e, portanto, mantém a aplicação e seu código-fonte compatíveis com essa licença.

- Projeto e documentação: https://www.astro.com/swisseph/
- Licenciamento: https://www.astro.com/swisseph/swephinfo_e.htm

A execução no navegador usa o pacote `swisseph-wasm`, de prolaxu, licenciado sob GPL-3.0-or-later: https://github.com/prolaxu/swisseph-wasm

Celeste não é afiliado, patrocinado ou endossado pela Astrodienst AG.

## Outros componentes

- Astronomy Engine — posições do céu observado; licença MIT: https://github.com/cosinekitty/astronomy
- Three.js — renderização WebGL; licença MIT: https://threejs.org/
- d3-celestial — catálogo de estrelas e linhas de constelações; licença BSD-3-Clause: https://github.com/ofrohn/d3-celestial
- Open-Meteo Geocoding API — busca de lugares, com dados GeoNames: https://open-meteo.com/en/docs/geocoding-api

As licenças de terceiros permanecem aplicáveis aos respectivos componentes e dados.
