import { calculateSwissNatal } from '../src/swiss-data.js';

const chart = await calculateSwissNatal({
  date: new Date('1990-04-17T12:00:00.000Z'),
  latitude: -23.5505,
  longitude: -46.6333,
});

const sun = chart.planets.find((planet) => planet.name === 'Sun');
const closeTo = (actual, expected, tolerance = 0.0001) => Math.abs(actual - expected) <= tolerance;

if (!closeTo(sun.eclipticLongitude, 27.213279, 0.0001)) {
  throw new Error(`Unexpected Sun longitude: ${sun.eclipticLongitude}`);
}
if (!closeTo(chart.ascendant, 61.48364, 0.0001)) {
  throw new Error(`Unexpected ascendant: ${chart.ascendant}`);
}
if (chart.planets.length !== 12 || chart.cusps.length !== 12) {
  throw new Error('Swiss Ephemeris result is incomplete.');
}
if (chart.observedPlanets.length !== 10 || chart.observedHouses.houses.length !== 12) {
  throw new Error('Swiss Ephemeris observed-sky projection is incomplete.');
}
if (!closeTo(chart.observedPlanets[0].altitude, 33.188901, 0.0001)) {
  throw new Error(`Unexpected observed Sun altitude: ${chart.observedPlanets[0].altitude}`);
}

console.log(`Swiss Ephemeris ${chart.version}: reference chart passed.`);
