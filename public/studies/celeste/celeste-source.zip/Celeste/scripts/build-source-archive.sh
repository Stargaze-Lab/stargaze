#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
dependency_root="$project_root/node_modules"
if [[ ! -d "$dependency_root/swisseph-wasm" ]]; then
  dependency_root="$(cd "$project_root/../.." && pwd)/node_modules"
fi
archive_tmp="$(mktemp -d)"
trap 'rm -rf "$archive_tmp"' EXIT

mkdir -p "$archive_tmp/Celeste" "$project_root/public"
rsync -a \
  --exclude node_modules \
  --exclude dist \
  --exclude .git \
  --exclude public/celeste-source.zip \
  --exclude public/wasm \
  "$project_root/" "$archive_tmp/Celeste/"

(cd "$archive_tmp" && zip -qr "$project_root/public/celeste-source.zip" Celeste)

# The current wrapper resolves these two Emscripten assets from /wasm at runtime.
mkdir -p "$project_root/public/wasm"
cp "$dependency_root/swisseph-wasm/wasm/swisseph.data" "$project_root/public/wasm/swisseph.data"
cp "$dependency_root/swisseph-wasm/wasm/swisseph.wasm" "$project_root/public/wasm/swisseph.wasm"
