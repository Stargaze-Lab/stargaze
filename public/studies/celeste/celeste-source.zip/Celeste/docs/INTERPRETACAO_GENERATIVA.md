# Interpretação generativa · proposta de integração

Celeste pode oferecer um botão **interpretação generativa** no cartão esquerdo. A chamada ao modelo deve passar por um endpoint protegido no servidor; a chave nunca deve ser incluída no JavaScript publicado.

## Fluxo recomendado

1. A pessoa seleciona um planeta, eixo ou aspecto.
2. Celeste envia apenas o contexto necessário para `POST /api/celeste-interpretation`.
3. O servidor valida a entrada, monta o prompt e chama o provedor de LLM.
4. O cartão mantém os dados objetivos e troca as três descrições por um único parágrafo curto.
5. Um botão **voltar aos dados** restaura a leitura original.

## Contrato sugerido

```json
{
  "language": "pt",
  "selection": {
    "type": "planet",
    "body": "Chiron",
    "sign": "Taurus",
    "degree": 0.7,
    "house": 7
  },
  "sourceMeanings": {
    "body": "Vulnerabilidades que podem se transformar em compreensão...",
    "sign": "Estabilidade, presença, constância...",
    "house": "Parcerias, relacionamentos, acordos..."
  },
  "promptVersion": "celeste-1"
}
```

Resposta:

```json
{
  "interpretation": "Quíron em Touro, na Casa 7, sugere...",
  "model": "identificador-do-modelo",
  "promptVersion": "celeste-1"
}
```

## Regras editoriais do prompt

- Escrever um único parágrafo de aproximadamente 80 a 120 palavras.
- Combinar os elementos fornecidos; não repetir as três definições em sequência.
- Usar linguagem simbólica e contemplativa, sem previsões, fatalismo ou diagnóstico.
- Não afirmar que a interpretação é uma verdade objetiva ou científica.
- Não inventar posições, aspectos ou dados que não estejam no payload.
- Para aspectos, explicar a dinâmica entre os dois astros e o tipo de aspecto.
- Responder no idioma selecionado na interface.

## Proteções necessárias

- Chave do provedor apenas no servidor.
- Limite de requisições por sessão/IP e limite diário global.
- Timeout curto com retorno à leitura fixa quando o modelo não responder.
- Cache pela combinação `mapa + seleção + idioma + versão do prompt`.
- Registro de custo e latência, sem guardar nome ou localização precisa da pessoa.
- Aviso discreto: “síntese simbólica gerada por IA”.

## Estados do botão

- Inicial: **interpretação generativa**.
- Carregando: **tecendo uma leitura…**.
- Sucesso: mostra o parágrafo e **voltar aos dados**.
- Erro: mantém a leitura fixa e informa que a síntese não está disponível.

O front-end pode ser conectado ao contrato acima independentemente do provedor de LLM. A implementação final depende apenas da escolha da hospedagem capaz de executar o endpoint protegido.
